import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

let supabase = null;

if (supabaseUrl && supabaseAnonKey) {
  supabase = createClient(supabaseUrl, supabaseAnonKey);
}

export const submitOrder = async (orderData) => {
  if (!supabase) {
    console.log('Supabase not configured. Order data:', orderData);
    return { id: 'MOCK-' + Date.now(), ...orderData };
  }
  const { data, error } = await supabase.from('orders').insert([orderData]).select();
  if (error) throw error;
  return data;
};

export const getMenuItems = async () => {
  if (!supabase) {
    return [];
  }
  const { data, error } = await supabase.from('menu_items').select('*');
  if (error) throw error;
  return data;
};

export const subscribeToCalls = (callback) => {
  if (!supabase) {
    console.log('Supabase not configured. Realtime calls disabled.');
    return () => {};
  }
  const subscription = supabase
    .channel('ai-calls')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'ai_calls' }, callback)
    .subscribe();
  return () => subscription.unsubscribe();
};

export default supabase;
