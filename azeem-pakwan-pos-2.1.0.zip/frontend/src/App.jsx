import { useState, useEffect } from 'react';
import LiveCallStream from './components/LiveCallStream';
import MenuGrid from './components/MenuGrid';
import CartSummary from './components/CartSummary';

function Clock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const pkr = time.toLocaleString('en-PK', {
    timeZone: 'Asia/Karachi',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
  const date = time.toLocaleString('en-PK', {
    timeZone: 'Asia/Karachi',
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  return (
    <div className="text-right">
      <div className="text-pos-accent font-bold text-xl md:text-2xl tabular-nums font-mono">{pkr}</div>
      <div className="text-pos-text-dim text-sm">{date}</div>
    </div>
  );
}

export default function App() {
  const [cart, setCart] = useState([]);
  const [activeTab, setActiveTab] = useState('bbq');
  const [deliveryArea, setDeliveryArea] = useState('FB Area');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [orderPlaced, setOrderPlaced] = useState(null);
  const [showMobilePanel, setShowMobilePanel] = useState('menu');

  const addToCart = (item) => {
    setCart((prev) => {
      const exists = prev.find((i) => i.name === item.name);
      if (exists) {
        return prev.map((i) =>
          i.name === item.name ? { ...i, qty: i.qty + 1 } : i
        );
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const removeFromCart = (name) => {
    setCart((prev) => prev.filter((i) => i.name !== name));
  };

  const updateQty = (name, delta) => {
    setCart((prev) =>
      prev
        .map((i) => (i.name === name ? { ...i, qty: i.qty + delta } : i))
        .filter((i) => i.qty > 0)
    );
  };

  const clearCart = () => {
    setCart([]);
    setOrderPlaced(null);
  };

  const deliveryFee =
    deliveryArea === 'FB Area' ? 150 : deliveryArea === 'Nazimabad' ? 200 : 180;
  const subtotal = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  const gst = subtotal * 0.13;
  const grandTotal = subtotal + deliveryFee + gst;

  const handlePlaceOrder = () => {
    const orderId = 'AZM-' + Date.now().toString(36).toUpperCase();
    setOrderPlaced({
      id: orderId,
      items: cart,
      subtotal,
      deliveryFee,
      gst,
      grandTotal,
      deliveryArea,
      deliveryAddress,
      paymentMethod,
    });
  };

  return (
    <div className="h-screen w-screen bg-pos-bg flex flex-col overflow-hidden">
      <header className="h-16 md:h-18 flex items-center justify-between px-4 md:px-8 border-b border-pos-border bg-white shadow-sm shrink-0">
        <div className="flex items-center gap-3 md:gap-6">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🍗</span>
            <h1 className="text-pos-accent font-extrabold text-xl md:text-2xl tracking-tight">
              Azeem Pakwan
            </h1>
          </div>
          <span className="hidden md:inline text-pos-text-dim text-sm font-medium border-l border-pos-border pl-4">
            AI POS & CALL CENTER
          </span>
        </div>
        <div className="flex items-center gap-4 md:gap-6">
          <div className="flex items-center gap-2 bg-pos-accent-light px-3 py-1.5 rounded-full">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pos-online opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-pos-online"></span>
            </span>
            <span className="text-pos-online text-sm font-bold">AI ONLINE</span>
          </div>
          <Clock />
        </div>
      </header>

      {/* Mobile Tab Bar */}
      <div className="md:hidden flex border-b border-pos-border bg-white shrink-0">
        {[
          { id: 'calls', label: '📞 Calls' },
          { id: 'menu', label: '🍽️ Menu' },
          { id: 'cart', label: `🧾 Cart${cart.length ? ` (${cart.length})` : ''}` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setShowMobilePanel(tab.id)}
            className={`flex-1 py-3 text-sm font-bold transition-all ${
              showMobilePanel === tab.id
                ? 'text-pos-accent border-b-2 border-pos-accent bg-pos-accent-light'
                : 'text-pos-text-dim'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main 3-Zone Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* LEFT: Live Call Stream */}
        <div className={`md:w-96 lg:w-[28rem] border-r border-pos-border overflow-y-auto shrink-0 bg-white
          ${showMobilePanel === 'calls' ? 'block w-full' : 'hidden'} md:block`}>
          <LiveCallStream />
        </div>

        {/* CENTER: Menu Grid */}
        <div className={`flex-1 overflow-y-auto bg-pos-bg
          ${showMobilePanel === 'menu' ? 'block w-full' : 'hidden'} md:block`}>
          <MenuGrid
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            cart={cart}
            addToCart={addToCart}
            updateQty={updateQty}
          />
        </div>

        {/* RIGHT: Cart Summary */}
        <div className={`lg:w-[30rem] md:w-96 border-l border-pos-border overflow-y-auto shrink-0 bg-white
          ${showMobilePanel === 'cart' ? 'block w-full' : 'hidden'} md:block`}>
          <CartSummary
            cart={cart}
            subtotal={subtotal}
            deliveryFee={deliveryFee}
            gst={gst}
            grandTotal={grandTotal}
            deliveryArea={deliveryArea}
            setDeliveryArea={setDeliveryArea}
            deliveryAddress={deliveryAddress}
            setDeliveryAddress={setDeliveryAddress}
            paymentMethod={paymentMethod}
            setPaymentMethod={setPaymentMethod}
            removeFromCart={removeFromCart}
            updateQty={updateQty}
            onPlaceOrder={handlePlaceOrder}
            orderPlaced={orderPlaced}
            clearCart={clearCart}
          />
        </div>
      </div>
    </div>
  );
}
