import { useState, useEffect, useCallback } from 'react';
import { subscribeToCalls } from '../services/supabaseClient';

export function useRealtimeOrders() {
  const [newOrder, setNewOrder] = useState(null);
  const [notification, setNotification] = useState(null);

  useEffect(() => {
    const unsubscribe = subscribeToCalls((payload) => {
      const order = payload.new;
      setNewOrder(order);
      setNotification({
        id: Date.now(),
        message: `Naya order aaya: ${order.customer_name || 'Unknown'}`,
        type: 'incoming_order',
      });
    });
    return unsubscribe;
  }, []);

  const dismissNotification = useCallback(() => {
    setNotification(null);
  }, []);

  return { newOrder, notification, dismissNotification };
}
