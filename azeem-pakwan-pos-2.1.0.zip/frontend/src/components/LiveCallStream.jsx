import { useState, useEffect, useRef } from 'react';

const mockTranscriptions = [
  { text: 'Salam, menu mein se Chicken Tikka aur Mighty Zinger chahta hoon', delay: 0 },
  { text: 'Delivery FB Area mein chahiye, Sector 15', delay: 3000 },
  { text: 'JazzCash payment karna hai', delay: 6000 },
  { text: 'Aur ek Family Platter bhi add kardein', delay: 9000 },
  { text: 'Coke aur garlic sauce bhi dal dein', delay: 12000 },
  { text: 'Mera number 0300-1234567 hai', delay: 15000 },
  { text: 'Order confirm karein please', delay: 18000 },
];

const statuses = [
  { label: 'AI PROCESSING', color: 'text-pos-ai-call', bg: 'bg-pos-ai-call-light', border: 'border-pos-ai-call/30' },
  { label: 'HUMAN ESCALATED', color: 'text-pos-warning', bg: 'bg-pos-warning-light', border: 'border-pos-warning/30' },
  { label: 'ORDER CONFIRMED', color: 'text-pos-accent', bg: 'bg-pos-accent-light', border: 'border-pos-accent/30' },
];

export default function LiveCallStream() {
  const [phoneConnected, setPhoneConnected] = useState(false);
  const [isCallActive, setIsCallActive] = useState(false);
  const [callerNumber, setCallerNumber] = useState('');
  const [visibleLines, setVisibleLines] = useState([]);
  const [statusIndex, setStatusIndex] = useState(0);
  const [demoMode, setDemoMode] = useState(false);
  const scrollRef = useRef(null);
  const audioRef = useRef(null);

  const startDemo = () => {
    setDemoMode(true);
    setPhoneConnected(true);
    setCallerNumber('+92 300-1234567');
    setIsCallActive(true);
    setVisibleLines([]);
    setStatusIndex(0);
  };

  const stopDemo = () => {
    setDemoMode(false);
    setPhoneConnected(false);
    setCallerNumber('');
    setIsCallActive(false);
    setVisibleLines([]);
  };

  useEffect(() => {
    if (!demoMode) return;
    const timers = [];
    mockTranscriptions.forEach((t) => {
      const timer = setTimeout(() => {
        setVisibleLines((prev) => [...prev, t.text]);
      }, t.delay);
      timers.push(timer);
    });
    return () => timers.forEach(clearTimeout);
  }, [demoMode]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [visibleLines]);

  useEffect(() => {
    if (!isCallActive) return;
    const interval = setInterval(() => {
      setStatusIndex((prev) => (prev + 1) % statuses.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [isCallActive]);

  const status = statuses[statusIndex];

  if (!phoneConnected) {
    return (
      <div className="p-5 md:p-6 flex flex-col h-full">
        <h2 className="text-pos-accent font-extrabold text-lg tracking-wider flex items-center gap-2 mb-6">
          <span>📞</span> CALL CENTER
        </h2>

        {/* WO Mic Setup Guide */}
        <div className="flex-1 flex flex-col items-center justify-center text-center">
          <div className="w-24 h-24 rounded-full bg-pos-accent-light flex items-center justify-center mb-5">
            <span className="text-4xl">📱</span>
          </div>
          <h3 className="text-pos-text font-bold text-xl mb-2">Phone Not Connected</h3>
          <p className="text-pos-text-dim text-sm mb-6 max-w-xs leading-relaxed">
            Connect your Android phone via <strong className="text-pos-text">WO Mic</strong> to receive live call audio.
          </p>

          <div className="bg-pos-bg rounded-xl p-5 w-full text-left space-y-4 mb-6">
            <h4 className="font-bold text-pos-text text-base flex items-center gap-2">
              <span>📋</span> Setup Guide
            </h4>
            <div className="space-y-3">
              {[
                { step: '1', title: 'Install WO Mic on Phone', desc: 'Google Play Store se WO Mic app install karein' },
                { step: '2', title: 'Install WO Mic on PC', desc: 'wolicheng.com/womic se Windows client download karein' },
                { step: '3', title: 'Select WiFi Mode', desc: 'Phone app mein WiFi mode select karein' },
                { step: '4', title: 'Connect', desc: 'PC client mein phone ka IP address enter karein' },
              ].map((s) => (
                <div key={s.step} className="flex items-start gap-3">
                  <span className="bg-pos-accent text-white w-7 h-7 rounded-full flex items-center justify-center text-sm font-bold shrink-0 mt-0.5">{s.step}</span>
                  <div>
                    <div className="font-bold text-pos-text text-sm">{s.title}</div>
                    <div className="text-pos-text-dim text-sm">{s.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={startDemo}
            className="px-8 py-3.5 bg-pos-accent text-white font-bold text-base rounded-xl hover:bg-pos-accent-hover transition-all shadow-lg shadow-pos-accent/20 w-full"
          >
            ▶ Start Demo Mode (No Phone)
          </button>
          <p className="text-pos-text-dim text-xs mt-3">Demo mode simulates a live call for testing</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-5 md:p-6 flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-pos-accent font-extrabold text-lg tracking-wider flex items-center gap-2">
          <span>{isCallActive ? '📞' : '📵'}</span> 
          {isCallActive ? 'LIVE CALL' : 'CALL CENTER'}
        </h2>
        <div className="flex items-center gap-2">
          {isCallActive && (
            <span className={`text-xs px-3 py-1 rounded-full font-bold ${status.bg} ${status.color} ${status.border} border`}>
              {status.label}
            </span>
          )}
          {demoMode && (
            <span className="text-xs bg-pos-warning-light text-pos-warning px-2 py-1 rounded-full font-bold border border-pos-warning/30">
              DEMO
            </span>
          )}
        </div>
      </div>

      {/* Caller ID */}
      <div className="bg-white border-2 border-pos-border rounded-xl p-4 mb-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-14 h-14 rounded-full bg-pos-accent-light flex items-center justify-center text-2xl">
                {isCallActive ? '🎧' : '📞'}
              </div>
              {isCallActive && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-pos-online rounded-full border-2 border-white">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pos-online opacity-75"></span>
                </span>
              )}
            </div>
            <div>
              <div className="text-pos-text font-bold text-lg">{isCallActive ? 'Active Call' : 'Waiting...'}</div>
              <div className="text-pos-text-dim text-sm font-mono">{callerNumber || 'No caller'}</div>
            </div>
          </div>
          <button
            onClick={() => { setIsCallActive(!isCallActive); if (!isCallActive) setVisibleLines([]); }}
            className={`text-sm px-4 py-2 rounded-full font-bold border-2 transition-all ${
              isCallActive
                ? 'bg-pos-danger-light text-pos-danger border-pos-danger/30 hover:bg-pos-danger/20'
                : 'bg-pos-accent-light text-pos-accent border-pos-accent/30 hover:bg-pos-accent/20'
            }`}
          >
            {isCallActive ? 'END CALL' : 'ANSWER'}
          </button>
        </div>
      </div>

      {/* Audio Visualizer */}
      <div className="bg-white border-2 border-pos-border rounded-xl p-4 mb-4 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <span className="text-pos-text-dim text-sm font-bold">Audio Visualizer</span>
          <span className={`text-xs font-bold ${isCallActive ? 'text-pos-online' : 'text-pos-text-dim'}`}>
            {isCallActive ? '● LIVE' : '○ IDLE'}
          </span>
        </div>
        <div className="flex items-end justify-center gap-1.5 h-16">
          {(isCallActive ? [20, 60, 40, 80, 30, 70, 50, 90, 35, 65, 45, 75] : [10, 15, 8, 12, 10, 15, 8, 12, 10, 15, 8, 12]).map((h, i) => (
            <div
              key={i}
              className={`w-2.5 rounded-t-sm ${isCallActive ? 'bg-pos-accent animate-wave' : 'bg-pos-border'}`}
              style={{
                height: `${h}%`,
                animationDelay: isCallActive ? `${i * 0.1}s` : '0s',
                animationDuration: isCallActive ? `${0.6 + (i % 3) * 0.2}s` : '0s',
              }}
            />
          ))}
        </div>
      </div>

      {/* Transcription Box */}
      <div className="flex-1 min-h-0">
        <div className="flex items-center justify-between mb-2">
          <span className="text-pos-text-dim text-sm font-bold">Live Transcription</span>
          {visibleLines.length > 0 && (
            <span className="text-xs text-pos-text-dim">{visibleLines.length} lines</span>
          )}
        </div>
        <div
          ref={scrollRef}
          className="bg-pos-bg border-2 border-pos-border rounded-xl p-4 h-full overflow-y-auto"
        >
          {!isCallActive ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <span className="text-3xl mb-3">📵</span>
              <div className="text-pos-text-dim text-sm font-medium">No Active Call</div>
              <div className="text-pos-text-dim/70 text-xs mt-1">Press ANSWER to start receiving audio</div>
            </div>
          ) : visibleLines.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <span className="animate-pulse text-2xl mb-3">🔊</span>
              <div className="text-pos-text-dim text-sm font-medium">Listening...</div>
              <div className="text-pos-text-dim/70 text-xs mt-1">Waiting for customer to speak</div>
            </div>
          ) : (
            visibleLines.map((line, i) => (
              <div
                key={i}
                className="text-pos-text text-sm mb-3 pb-3 border-b border-pos-border last:border-0 animate-slide-in"
              >
                <span className="text-pos-accent font-bold mr-2 text-xs">#{String(i + 1).padStart(2, '0')}</span>
                {line}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
