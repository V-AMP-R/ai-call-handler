const menuData = {
  bbq: [
    { name: 'Chicken Tikka', price: 350, desc: '6 pcs, spicy grilled tikka with herbs' },
    { name: 'Beef Bihari Kabab', price: 420, desc: '2 pcs, traditional Bihari style beef' },
    { name: 'Seekh Kabab', price: 380, desc: '6 pcs, minced beef seekh kabab' },
    { name: 'Reshmi Kabab', price: 450, desc: '4 pcs, creamy chicken reshmi kabab' },
    { name: 'Malai Boti', price: 480, desc: '8 pcs, tender malai chicken boti' },
  ],
  deals: [
    { name: 'Family Platter', price: 1850, desc: 'Serves 4-5, mixed BBQ + naan + salad' },
    { name: 'Mighty Zinger', price: 650, desc: 'Jumbo zinger burger + fries + drink' },
    { name: 'Zinger Stacker', price: 750, desc: 'Double decker zinger + extra cheese' },
    { name: 'Crispy Duo', price: 890, desc: '2 zingers + 2 fries + 2 drinks' },
    { name: 'Mega Feast', price: 1450, desc: '4 zingers + large fries + 4 drinks' },
    { name: 'Student Special', price: 320, desc: '1 zinger + fries + drink (discount)' },
  ],
  daig: [
    { name: 'Beef Biryani Daig', price: 4500, desc: 'Full daig, serves 12-15 persons' },
    { name: 'Degi Korma', price: 3800, desc: 'Full daig chicken korma, serves 12-15' },
    { name: 'Chicken Pulao Daig', price: 3200, desc: 'Full daig, fragrant chicken pulao' },
    { name: 'Nihabi Daig', price: 5000, desc: 'Full daig, rich beef nihari' },
    { name: 'Haleem Daig', price: 4200, desc: 'Full daig, traditional haleem' },
    { name: 'Mixed Daig', price: 6000, desc: 'Half biryani + half korma, serves 15-20' },
  ],
};

const tabs = [
  { id: 'bbq', label: 'BBQ 🔥' },
  { id: 'deals', label: 'DEALS 🍔' },
  { id: 'daig', label: 'DAIG CATERING 🍛' },
];

export default function MenuGrid({ activeTab, setActiveTab, cart, addToCart, updateQty }) {
  const items = menuData[activeTab];

  return (
    <div className="p-4 md:p-6">
      {/* Tabs */}
      <div className="flex gap-2 md:gap-3 mb-5 pb-3 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-5 md:px-7 py-3 rounded-xl text-sm md:text-base font-bold transition-all duration-200 whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-pos-accent text-white shadow-lg shadow-pos-accent/30 scale-105'
                : 'bg-white text-pos-text-dim hover:bg-pos-accent-light hover:text-pos-accent border-2 border-pos-border hover:border-pos-accent/30'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Menu Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-5">
        {items.map((item) => {
          const cartItem = cart.find((c) => c.name === item.name);
          const qty = cartItem ? cartItem.qty : 0;
          return (
            <div
              key={item.name}
              className={`bg-white border-2 rounded-xl p-5 transition-all duration-200 hover:shadow-md ${
                qty > 0 ? 'border-pos-accent shadow-md shadow-pos-accent/10' : 'border-pos-border hover:border-pos-accent/30'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-pos-text font-bold text-base md:text-lg">{item.name}</h3>
                    {qty > 0 && (
                      <span className="bg-pos-accent text-white text-xs font-bold px-2.5 py-1 rounded-full">
                        {qty}
                      </span>
                    )}
                  </div>
                  <p className="text-pos-text-dim text-sm mt-1">{item.desc}</p>
                </div>
                <span className="text-pos-accent font-extrabold text-base md:text-lg whitespace-nowrap ml-2 tabular-nums">
                  Rs. {item.price.toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-end gap-3 mt-4">
                {qty > 0 ? (
                  <div className="flex items-center bg-pos-bg rounded-xl border-2 border-pos-border">
                    <button
                      onClick={() => updateQty(item.name, -1)}
                      className="px-4 py-2 bg-pos-warning-light text-pos-warning hover:bg-pos-warning/30 rounded-l-xl transition-all font-bold text-lg"
                    >
                      −
                    </button>
                    <span className="text-pos-text font-bold text-base min-w-[28px] text-center tabular-nums">{qty}</span>
                    <button
                      onClick={() => addToCart(item)}
                      className="px-4 py-2 bg-pos-accent-light text-pos-accent hover:bg-pos-accent/30 rounded-r-xl transition-all font-bold text-lg"
                    >
                      +
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => addToCart(item)}
                    className="px-6 py-2.5 bg-pos-accent text-white hover:bg-pos-accent-hover rounded-xl transition-all font-bold text-sm md:text-base shadow-sm"
                  >
                    + Add to Order
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
