export default function CartSummary({
  cart, subtotal, deliveryFee, gst, grandTotal,
  deliveryArea, setDeliveryArea, deliveryAddress, setDeliveryAddress,
  paymentMethod, setPaymentMethod, removeFromCart, updateQty,
  onPlaceOrder, orderPlaced, clearCart,
}) {
  if (orderPlaced) {
    return (
      <div className="p-5 md:p-6 flex flex-col h-full">
        <div className="flex-1 flex flex-col items-center justify-center text-center animate-fade-in">
          <div className="w-24 h-24 rounded-full bg-pos-accent-light flex items-center justify-center mb-5">
            <span className="text-5xl">✅</span>
          </div>
          <h2 className="text-pos-accent font-extrabold text-2xl mb-2">Order Placed!</h2>
          <p className="text-pos-text-dim text-sm mb-6">Azeem Pakwan ka shukriya!</p>
          <div className="bg-pos-bg border-2 border-pos-border rounded-xl p-5 mb-6 w-full max-w-sm">
            <div className="text-pos-text-dim text-xs font-bold mb-1">Order ID</div>
            <div className="text-pos-text font-mono font-extrabold text-xl tracking-wider">{orderPlaced.id}</div>
            <div className="border-t-2 border-pos-border mt-4 pt-4">
              {orderPlaced.items.map((item) => (
                <div key={item.name} className="flex justify-between text-sm text-pos-text-dim mb-2">
                  <span>{item.qty}x {item.name}</span>
                  <span className="tabular-nums">Rs. {(item.price * item.qty).toLocaleString()}</span>
                </div>
              ))}
              <div className="border-t-2 border-pos-border mt-3 pt-3 flex justify-between text-pos-text font-extrabold text-lg">
                <span>Total</span>
                <span className="tabular-nums">Rs. {orderPlaced.grandTotal.toLocaleString()}</span>
              </div>
            </div>
            <div className="text-pos-text-dim text-sm mt-3 font-medium">
              {orderPlaced.paymentMethod === 'cash' ? '💵 Cash on Delivery' :
               orderPlaced.paymentMethod === 'jazzcash' ? '📱 JazzCash' : '📱 EasyPaisa'}
            </div>
          </div>
          <button
            onClick={clearCart}
            className="px-10 py-3.5 bg-pos-accent text-white font-extrabold text-base rounded-xl hover:bg-pos-accent-hover transition-all shadow-lg shadow-pos-accent/20"
          >
            New Order
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-5 md:p-6 flex flex-col h-full">
      <h2 className="text-pos-accent font-extrabold text-lg tracking-wider mb-5 flex items-center gap-2">
        <span>🧾</span> ORDER SUMMARY
        {cart.length > 0 && (
          <span className="bg-pos-accent text-white text-xs font-bold px-2.5 py-1 rounded-full ml-auto">
            {cart.length} items
          </span>
        )}
      </h2>

      {/* Cart Items */}
      <div className="flex-1 min-h-0 overflow-y-auto mb-5 space-y-3">
        {cart.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <span className="text-4xl mb-3">🛒</span>
            <div className="text-pos-text-dim text-base font-medium">Cart is empty</div>
            <div className="text-pos-text-dim/70 text-sm mt-1">Select items from the menu</div>
          </div>
        ) : (
          cart.map((item) => (
            <div
              key={item.name}
              className="bg-white border-2 border-pos-border rounded-xl p-4 animate-slide-in hover:border-pos-accent/30 transition-all"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-pos-text font-bold text-base truncate flex-1">{item.name}</span>
                <button
                  onClick={() => removeFromCart(item.name)}
                  className="text-pos-text-dim hover:text-pos-danger text-sm ml-2 shrink-0 font-bold"
                >
                  ✕ Remove
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateQty(item.name, -1)}
                    className="w-8 h-8 flex items-center justify-center bg-pos-warning-light text-pos-warning hover:bg-pos-warning/30 rounded-lg text-base font-bold"
                  >
                    −
                  </button>
                  <span className="text-pos-text font-bold text-base min-w-[24px] text-center tabular-nums">{item.qty}</span>
                  <button
                    onClick={() => updateQty(item.name, 1)}
                    className="w-8 h-8 flex items-center justify-center bg-pos-accent-light text-pos-accent hover:bg-pos-accent/30 rounded-lg text-base font-bold"
                  >
                    +
                  </button>
                </div>
                <span className="text-pos-accent font-extrabold text-base tabular-nums">
                  Rs. {(item.price * item.qty).toLocaleString()}
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Delivery Info */}
      <div className="space-y-4 mb-5">
        <div>
          <label className="text-pos-text-dim text-sm font-bold mb-1.5 block">Delivery Area</label>
          <select
            value={deliveryArea}
            onChange={(e) => setDeliveryArea(e.target.value)}
            className="w-full bg-white border-2 border-pos-border rounded-xl px-4 py-3 text-pos-text text-base focus:outline-none focus:border-pos-accent transition-all"
          >
            <option value="FB Area">FB Area (Rs. 150)</option>
            <option value="Nazimabad">Nazimabad (Rs. 200)</option>
            <option value="Gulshan-e-Iqbal">Gulshan-e-Iqbal (Rs. 180)</option>
            <option value="North Nazimabad">North Nazimabad (Rs. 200)</option>
          </select>
        </div>
        <div>
          <label className="text-pos-text-dim text-sm font-bold mb-1.5 block">Delivery Address</label>
          <textarea
            value={deliveryAddress}
            onChange={(e) => setDeliveryAddress(e.target.value)}
            placeholder="House #, Street, Sector, FB Area / Nazimabad..."
            className="w-full bg-white border-2 border-pos-border rounded-xl px-4 py-3 text-pos-text text-base placeholder:text-pos-text-dim/50 focus:outline-none focus:border-pos-accent transition-all resize-none"
            rows={2}
          />
        </div>
        <div>
          <label className="text-pos-text-dim text-sm font-bold mb-1.5 block">Payment Method</label>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setPaymentMethod('cash')}
              className={`py-3 rounded-xl text-sm font-bold border-2 transition-all ${
                paymentMethod === 'cash'
                  ? 'bg-pos-accent text-white border-pos-accent shadow-md'
                  : 'bg-white text-pos-text-dim border-pos-border hover:border-pos-accent/50'
              }`}
            >
              💵 Cash
            </button>
            <button
              onClick={() => setPaymentMethod('jazzcash')}
              className={`py-3 rounded-xl text-sm font-bold border-2 transition-all ${
                paymentMethod === 'jazzcash'
                  ? 'bg-pos-ai-call text-white border-pos-ai-call shadow-md'
                  : 'bg-white text-pos-text-dim border-pos-border hover:border-pos-ai-call/50'
              }`}
            >
              📱 JazzCash
            </button>
            <button
              onClick={() => setPaymentMethod('easypaisa')}
              className={`py-3 rounded-xl text-sm font-bold border-2 transition-all ${
                paymentMethod === 'easypaisa'
                  ? 'bg-pos-ai-call text-white border-pos-ai-call shadow-md'
                  : 'bg-white text-pos-text-dim border-pos-border hover:border-pos-ai-call/50'
              }`}
            >
              📱 EasyPaisa
            </button>
          </div>
        </div>
      </div>

      {/* Total Breakdown */}
      <div className="border-t-2 border-pos-border pt-4 space-y-2">
        <div className="flex justify-between text-base text-pos-text-dim">
          <span>Subtotal</span>
          <span className="tabular-nums">Rs. {subtotal.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-base text-pos-text-dim">
          <span>Delivery Fee</span>
          <span className="tabular-nums">Rs. {deliveryFee.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-base text-pos-text-dim">
          <span>GST (13%)</span>
          <span className="tabular-nums">Rs. {gst.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-xl font-extrabold text-pos-accent border-t-2 border-pos-border pt-3">
          <span>Grand Total</span>
          <span className="tabular-nums">Rs. {grandTotal.toLocaleString()}</span>
        </div>
      </div>

      {/* Place Order Button */}
      <button
        onClick={onPlaceOrder}
        disabled={cart.length === 0}
        className={`w-full mt-5 py-4 rounded-xl font-extrabold text-lg transition-all ${
          cart.length > 0
            ? 'bg-pos-accent text-white hover:bg-pos-accent-hover shadow-lg shadow-pos-accent/20 active:scale-[0.98]'
            : 'bg-pos-border/30 text-pos-text-dim cursor-not-allowed border-2 border-pos-border'
        }`}
      >
        {cart.length > 0 ? `Place Order — Rs. ${grandTotal.toLocaleString()}` : 'Place Order'}
      </button>
    </div>
  );
}
