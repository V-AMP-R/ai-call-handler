const GEMINI_MODEL = 'gemini-2.0-flash';
const GEMINI_API = 'https://generativelanguage.googleapis.com/v1beta/models';
let MENU_CONTEXT = '';

export async function loadMenuContext() {
  if (!window.api) return;
  const imgs = await window.api.getMenuImages();
  if (imgs.length === 0) { MENU_CONTEXT = ''; return; }

  // Read Gemini key from main process (in memory)
  const apiKey = window.__geminiKey || '';
  if (!apiKey) { MENU_CONTEXT = 'Menu images present but no API key.'; return; }

  try {
    const img = imgs[0];
    const resp = await fetch(img.url);
    const blob = await resp.blob();
    const base64 = await new Promise(resolve => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result.split(',')[1]);
      reader.readAsDataURL(blob);
    });

    const res = await fetch(`${GEMINI_API}/${GEMINI_MODEL}:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [
          { text: 'Extract all menu items. Return ONLY JSON array: [{"name":"...","price":number}]' },
          { inlineData: { mimeType: 'image/jpeg', data: base64 } },
        ]}],
        generationConfig: { temperature: 0.1, maxOutputTokens: 1024 },
      }),
    });
    if (!res.ok) { MENU_CONTEXT = 'Menu analysis failed.'; return; }
    const data = await res.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
    const match = text.match(/\[[\s\S]*\]/);
    const items = match ? JSON.parse(match[0]) : [];
    MENU_CONTEXT = items.length > 0
      ? 'MENU:\n' + items.map(i => `  ✓ ${i.name} — Rs. ${i.price}`).join('\n')
      : 'Menu images found but no items extracted.';
  } catch { MENU_CONTEXT = 'Menu loaded but AI unavailable.'; }

  // Analyze remaining images
  for (let i = 1; i < imgs.length && i < 3; i++) {
    try {
      const resp = await fetch(imgs[i].url);
      const blob = await resp.blob();
      const base64 = await new Promise(r => { const f = new FileReader(); f.onloadend = () => r(f.result.split(',')[1]); f.readAsDataURL(blob); });
      const res = await fetch(`${GEMINI_API}/${GEMINI_MODEL}:generateContent?key=${apiKey}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [
          { text: 'Extract menu items as JSON array: [{"name":"...","price":number}]' },
          { inlineData: { mimeType: 'image/jpeg', data: base64 } },
        ]}], generationConfig: { temperature: 0.1, maxOutputTokens: 1024 } }),
      });
      if (res.ok) {
        const data = await res.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
        const match = text.match(/\[[\s\S]*\]/);
        const items = match ? JSON.parse(match[0]) : [];
        if (items.length > 0) {
          MENU_CONTEXT += '\n' + items.map(i => `  ✓ ${i.name} — Rs. ${i.price}`).join('\n');
        }
      }
    } catch {}
  }
}

export async function getChatResponse(userMessage, history = [], apiKey) {
  const key = apiKey || window.__geminiKey || '';
  if (!key) return 'No Gemini API key available.';

  const system = `You are "Azeem Pakwan AI Munshi" — a Pakistani restaurant AI call operator.
Respond in the SAME language the customer uses. Auto-detect their language.
Keep responses 1-2 sentences. Be warm and professional.
${MENU_CONTEXT || 'No menu loaded.'}
Only take orders from the menu above. If item is not on menu, say it's unavailable.
Always confirm the order. If order is confirmed, output: ORDER: item1=qty, item2=qty on a new line.
End with "Khuda Hafiz" when order is complete.`;

  const contents = [
    { role: 'user', parts: [{ text: system }] },
    { role: 'model', parts: [{ text: 'Understood. I will auto-detect the language and respond accordingly.' }] },
    ...history.map(h => ({ role: h.role === 'ai' ? 'model' : 'user', parts: [{ text: h.text }] })),
    { role: 'user', parts: [{ text: userMessage }] },
  ];

  try {
    const res = await fetch(`${GEMINI_API}/${GEMINI_MODEL}:generateContent?key=${key}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents, generationConfig: { temperature: 0.7, maxOutputTokens: 256 } }),
    });
    if (!res.ok) return 'AI unavailable.';
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response.';
  } catch { return 'Network error.'; }
}

export function speakText(text, onEnd = () => {}) {
  if (!window.speechSynthesis) { onEnd(); return; }
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 0.9;
  u.pitch = 1.05;
  const voices = window.speechSynthesis.getVoices();
  const pref = voices.find(v => v.lang.startsWith('ur') || v.lang.startsWith('hi') || v.lang.startsWith('en'));
  if (pref) u.voice = pref;
  u.onend = onEnd;
  u.onerror = onEnd;
  window.speechSynthesis.speak(u);
}

export function stopSpeaking() { if (window.speechSynthesis) window.speechSynthesis.cancel(); }

export async function startAudioCapture(deviceId) {
  try {
    const constraints = deviceId && deviceId !== 'default'
      ? { audio: { deviceId: { exact: deviceId } } }
      : { audio: true };
    return await navigator.mediaDevices.getUserMedia(constraints);
  } catch (err) {
    if (err.name === 'NotAllowedError') throw new Error('Mic access denied.');
    if (err.name === 'NotFoundError') throw new Error('No mic. Install WO Mic.');
    throw new Error(err.message);
  }
}

export function stopAudioCapture(stream) {
  if (stream) {
    if (stream._processInterval) clearInterval(stream._processInterval);
    if (stream._audioCtx) stream._audioCtx.close();
    stream.getTracks().forEach(t => t.stop());
  }
}
