import { useState, useEffect } from 'react';
import ActivationScreen from './components/ActivationScreen';
import MainTable from './components/MainTable';
import { loadMenuContext } from './services/gemini';

const APP_VERSION = '2.0.0';

export default function App() {
  const [booted, setBooted] = useState(false);
  const [activated, setActivated] = useState(false);
  const [restaurantStatus, setRestaurantStatus] = useState('running');
  const [updateInfo, setUpdateInfo] = useState(null);
  const [updateVisible, setUpdateVisible] = useState(false);

  useEffect(() => {
    if (!window.api) {
      setBooted(true);
      setActivated(true);
      return;
    }

    loadMenuContext();

    window.api.checkLicense().then(async lic => {
      if (!lic || !lic.valid) {
        setBooted(true);
        return;
      }
      const v = await window.api.validate();
      if (v.valid) {
        setActivated(true);
        setRestaurantStatus(v.status || 'running');
      } else {
        await window.api.deleteLicense();
      }
      setBooted(true);
    });

    window.api.getAppVersion().then(v => {});

    window.api.onUpdateAvailable((info) => {
      setUpdateInfo(info);
      setUpdateVisible(true);
    });
  }, []);

  const handleToggleStatus = async () => {
    if (!window.api) return;
    if (restaurantStatus === 'running') {
      await window.api.stopRestaurant();
      setRestaurantStatus('maintenance');
    } else {
      const r = await window.api.startRestaurant();
      if (r.status !== 'ERROR') setRestaurantStatus('running');
    }
  };

  const handleUpdateNow = async () => {
    setUpdateVisible(false);
    await window.api.applyUpdate();
  };

  const handleUpdateLater = () => {
    setUpdateVisible(false);
  };

  if (!booted) {
    return (
      <div className="h-screen w-screen bg-[#f5f0e8] flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-3 border-[#e67800] border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return activated ? (
    <>
      {updateVisible && updateInfo && (
        <div className="update-banner">
          <span>
            📦 Update v{updateInfo.latestVersion} available! <span className="text-xs opacity-75">({updateInfo.latestVersion !== APP_VERSION ? 'New version' : 'Latest'})</span>
          </span>
          <button onClick={handleUpdateNow} className="btn-now">Update Now</button>
          <button onClick={handleUpdateLater} className="btn-later">Later</button>
        </div>
      )}

      {restaurantStatus === 'stopped' && (
        <div className="maintenance-overlay">
          <div className="text-center">
            <span className="text-6xl mb-4 block">🔧</span>
            <h1 className="text-4xl font-bold mb-2">UNDER MAINTENANCE</h1>
            <p className="text-xl opacity-80 mb-6">This restaurant is currently not accepting calls</p>
            <button onClick={handleToggleStatus} className="toggle-switch">
              ▶ Start Restaurant
            </button>
          </div>
        </div>
      )}

      {restaurantStatus === 'maintenance' && (
        <div className="bg-amber-50 border-b border-amber-300 px-5 py-2 text-amber-800 text-xs font-bold text-center">
          🔧 MAINTENANCE MODE - Restaurant is paused for maintenance
        </div>
      )}

      <MainTable
        restaurantStatus={restaurantStatus}
        onToggleStatus={handleToggleStatus}
      />
    </>
  ) : (
    <ActivationScreen onActivated={() => setActivated(true)} />
  );
}
