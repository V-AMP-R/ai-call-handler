export default function UpdateModal({ data, onApply, onClose }) {
  const progress = data.progress || 0;
  const isChecking = data.status === 'checking';
  const isDownloading = data.status === 'downloading';
  const isReady = data.ready;
  const isError = data.status === 'error';
  const isDone = isReady;

  return (
    <div className="update-modal-backdrop" onClick={onClose}>
      <div className="update-modal" onClick={e => e.stopPropagation()}>
        <div className="update-modal-header">
          <span className="text-lg">📦</span>
          <h3>Software Update</h3>
        </div>

        <div className="update-modal-body">
          <div className="update-info-row">
            <span className="update-label">Current version:</span>
            <span className="update-value">{data.currentVersion || '—'}</span>
          </div>
          <div className="update-info-row">
            <span className="update-label">Latest version:</span>
            <span className="update-value">{data.latestVersion || 'Checking...'}</span>
          </div>

          {isChecking && (
            <div className="update-status checking">
              <div className="animate-spin w-5 h-5 border-2 border-[#e67800] border-t-transparent rounded-full"></div>
              <span>Checking for updates...</span>
            </div>
          )}

          {isDownloading && !isReady && (
            <>
              <div className="update-status downloading">
                <span>Downloading update v{data.latestVersion}...</span>
              </div>
              <div className="update-progress-bar">
                <div className="update-progress-fill" style={{ width: `${Math.min(progress, 100)}%` }}></div>
              </div>
              <div className="update-progress-text">{Math.round(progress)}%</div>
            </>
          )}

          {isError && (
            <div className="update-status error">
              <span>⚠️ Update failed. Please try again or download manually.</span>
            </div>
          )}

          {isReady && (
            <div className="update-status ready">
              <span>✅ Update v{data.latestVersion} ready to install</span>
            </div>
          )}
        </div>

        <div className="update-modal-footer">
          {!isDone && !isError && (
            <button onClick={onClose} className="update-btn cancel">Cancel</button>
          )}
          {isError && (
            <button onClick={onClose} className="update-btn cancel">Close</button>
          )}
          {isReady && (
            <button onClick={onApply} className="update-btn apply">Apply & Restart</button>
          )}
        </div>
      </div>
    </div>
  );
}