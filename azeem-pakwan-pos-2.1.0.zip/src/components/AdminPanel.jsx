import { useState, useEffect } from 'react';

export default function AdminPanel({ onClose }) {
  const [apiKey, setApiKey] = useState('');
  const [apiKeyMsg, setApiKeyMsg] = useState('');
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cleanupMsg, setCleanupMsg] = useState('');

  useEffect(() => {
    if (window.api) {
      window.api.getGeminiKey().then(k => {
        if (k) setApiKey(k);
      });
      loadRestaurants();
    } else {
      setLoading(false);
    }
  }, []);

  const loadRestaurants = async () => {
    setLoading(true);
    try {
      const r = await window.api.getAllRestaurants();
      if (r.status === 'OK') setRestaurants(r.data || []);
      else setRestaurants([]);
    } catch (e) {
      setRestaurants([]);
    }
    setLoading(false);
  };

  const handleSaveApiKey = async () => {
    setApiKeyMsg('');
    if (!apiKey.trim()) { setApiKeyMsg('Enter a valid API key'); return; }
    try {
      await window.api.setGeminiKey(apiKey.trim());
      window.__geminiKey = apiKey.trim();
      setApiKeyMsg('API key saved successfully');
    } catch (e) {
      setApiKeyMsg('Failed to save API key: ' + e.message);
    }
  };

  const handleCleanup = async () => {
    setCleanupMsg('');
    if (!window.confirm('Remove all inactive device registrations?')) return;
    try {
      const r = await window.api.cleanupInactive();
      setCleanupMsg(r.data?.message || 'Cleanup completed');
      loadRestaurants();
    } catch (e) {
      setCleanupMsg('Cleanup failed: ' + e.message);
    }
  };

  return (
    <div className="admin-panel-backdrop" onClick={onClose}>
      <div className="admin-panel" onClick={e => e.stopPropagation()}>
        <div className="admin-panel-header">
          <span className="text-lg">⚙</span>
          <h3>Admin Settings</h3>
          <button onClick={onClose} className="admin-close-btn">✕</button>
        </div>

        <div className="admin-panel-body">
          {/* Gemini API Key */}
          <div className="admin-section">
            <h4 className="admin-section-title">Gemini API Key</h4>
            <div className="admin-api-key-row">
              <input
                type="password"
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
                placeholder="Enter Gemini API key..."
                className="admin-input"
              />
              <button onClick={handleSaveApiKey}
                className="admin-btn primary">
                Save
              </button>
            </div>
            {apiKeyMsg && (
              <div className={`admin-msg ${apiKeyMsg.includes('success') ? 'success' : 'error'}`}>
                {apiKeyMsg}
              </div>
            )}
          </div>

          {/* Registered Restaurants */}
          <div className="admin-section">
            <h4 className="admin-section-title">
              Registered Restaurants
              <span className="admin-count">{restaurants.length}</span>
            </h4>
            {loading ? (
              <div className="admin-loading">Loading...</div>
            ) : restaurants.length === 0 ? (
              <div className="admin-empty">No restaurants registered</div>
            ) : (
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Address</th>
                      <th>Status</th>
                      <th>Last Heartbeat</th>
                    </tr>
                  </thead>
                  <tbody>
                    {restaurants.map((r, i) => (
                      <tr key={r.id || i}>
                        <td>{r.restaurant_name || '—'}</td>
                        <td>{r.address || '—'}</td>
                        <td>
                          <span className={`status-badge ${r.status === 'running' ? 'active' : r.status === 'maintenance' ? 'maintenance' : 'inactive'}`}>
                            {r.status || 'unknown'}
                          </span>
                        </td>
                        <td className="text-[10px]">{r.last_heartbeat ? new Date(r.last_heartbeat).toLocaleString() : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Cleanup */}
          <div className="admin-section">
            <h4 className="admin-section-title">Device Cleanup</h4>
            <p className="admin-desc">Remove inactive devices that haven't connected in over 60 seconds.</p>
            <button onClick={handleCleanup} className="admin-btn danger">
              Cleanup Inactive Devices
            </button>
            {cleanupMsg && (
              <div className="admin-msg success">{cleanupMsg}</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}