import { useState, useEffect, useRef, useCallback } from 'react';
import { getChatResponse, speakText, stopSpeaking, startAudioCapture, stopAudioCapture } from '../services/gemini';
import UpdateModal from './UpdateModal';
import AdminPanel from './AdminPanel';

let callIdCounter = 0;
let geminiKey = '';

export default function MainTable({ restaurantStatus, onToggleStatus }) {
  const [calls, setCalls] = useState([]);
  const [phoneConnected, setPhoneConnected] = useState(false);
  const [micDevices, setMicDevices] = useState([]);
  const [selectedMic, setSelectedMic] = useState('default');
  const [statusMsg, setStatusMsg] = useState('');
  const [menuImages, setMenuImages] = useState([]);
  const [showMicMenu, setShowMicMenu] = useState(false);
  const [menuReady, setMenuReady] = useState(false);
  const [updateModalOpen, setUpdateModalOpen] = useState(false);
  const [updateData, setUpdateData] = useState(null);
  const [adminPanelOpen, setAdminPanelOpen] = useState(false);

  useEffect(() => {
    if (window.api) {
      window.api.getGeminiKey().then(k => {
        geminiKey = k || '';
        if (k) window.__geminiKey = k;
      });
      window.api.getMenuImages().then(imgs => {
        setMenuImages(imgs);
        if (imgs.length > 0) setMenuReady(true);
      });
    }
    refreshMics();
    const t = setInterval(refreshMics, 5000);
    return () => clearInterval(t);
  }, []);

  const refreshMics = async () => {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const mics = devices.filter(d => d.kind === 'audioinput');
      setMicDevices(mics);
      setPhoneConnected(mics.length > 0);
      const woMic = mics.find(d => d.label?.toLowerCase().includes('wo') || d.label?.toLowerCase().includes('mic'));
      if (woMic) setSelectedMic(woMic.deviceId);
    } catch {}
  };

  const addCall = async () => {
    if (calls.length >= 5) { setStatusMsg('Maximum 5 simultaneous calls.'); return; }
    if (micDevices.length === 0 && !window.__demoMode) {
      window.__demoMode = true;
      addDemoCall();
      return;
    }

    const id = ++callIdCounter;
    const newCall = {
      id,
      label: `Call #${id}`,
      status: 'connecting',
      items: [],
      total: 0,
      stream: null,
      audioCtx: null,
      analyser: null,
      transcript: '',
    };

    setCalls(prev => [...prev, newCall]);
    setStatusMsg(`Call #${id} connecting...`);

    try {
      const stream = await startAudioCapture(selectedMic);
      newCall.stream = stream;
      newCall.status = 'active';
      setStatusMsg(`Call #${id} active`);
      setCalls(prev => prev.map(c => c.id === id ? { ...c, status: 'active' } : c));
      startCallProcessing(id, stream);
    } catch (err) {
      newCall.status = 'error';
      newCall.error = err.message;
      setStatusMsg(`Call #${id} failed: ${err.message}`);
      setCalls(prev => prev.map(c => c.id === id ? { ...c, status: 'error', error: err.message } : c));
    }
  };

  const startCallProcessing = (callId, stream) => {
    const ctx = new AudioContext();
    const src = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    src.connect(analyser);
    const buf = new Uint8Array(analyser.frequencyBinCount);

    let silenceMs = 0;
    let lastProcess = 0;
    let conversation = [{ role: 'ai', text: menuReady
      ? 'Assalam-o-Alaikum! Azeem Pakwan mein khush amdeed! Mein AI Digital Munshi hoon. Aap kis language mein baat kareinge?'
      : 'Assalam-o-Alaikum! Kya app order dena chahate hain?' }];

    speakText(conversation[0].text, () => {});

    const interval = setInterval(async () => {
      analyser.getByteFrequencyData(buf);
      const avg = buf.reduce((a, b) => a + b, 0) / buf.length;
      silenceMs = avg < 10 ? silenceMs + 500 : 0;

      if (silenceMs > 3000 && Date.now() - lastProcess > 8000) {
        silenceMs = 0;
        lastProcess = Date.now();
        setStatusMsg(`Call #${callId}: processing...`);

        const userMsg = 'The customer has finished speaking. Respond appropriately based on the conversation so far. If they placed an order, confirm it and output ORDER: item1=qty, item2=qty on a new line.';
        const response = await getChatResponse(userMsg, conversation, geminiKey);
        conversation.push({ role: 'ai', text: response });

        const orderMatch = response.match(/ORDER:\s*(.+)/i);
        if (orderMatch) {
          const orderStr = orderMatch[1];
          const items = orderStr.split(',').map(s => s.trim()).filter(Boolean);
          const parsedItems = [];
          for (const item of items) {
            const parts = item.split('=');
            if (parts.length === 2) {
              parsedItems.push({ name: parts[0].trim(), qty: parseInt(parts[1]) || 1, price: 0, total: 0 });
            }
          }
          if (parsedItems.length > 0) {
            setCalls(prev => prev.map(c => c.id === callId ? {
              ...c, items: [...c.items, ...parsedItems],
              total: c.total + parsedItems.reduce((s, i) => s + i.total, 0),
            } : c));
          }
        }

        speakText(response, () => {});

        if (response.toLowerCase().includes('khuda hafiz') || response.toLowerCase().includes('thank you') || response.toLowerCase().includes('shukriya')) {
          setStatusMsg(`Call #${callId}: completed`);
          setCalls(prev => prev.map(c => c.id === callId ? { ...c, status: 'completed' } : c));
          clearInterval(interval);
          if (stream._audioCtx) stream._audioCtx.close();
          if (stream) stopAudioCapture(stream);
        }
      }
    }, 500);

    stream._processInterval = interval;
    stream._audioCtx = ctx;
    stream._analyser = analyser;
  };

  const endCall = (callId) => {
    setCalls(prev => prev.filter(c => c.id !== callId));
    const call = calls.find(c => c.id === callId);
    if (call?.stream) {
      stopAudioCapture(call.stream);
      if (call.stream._audioCtx) call.stream._audioCtx.close();
    }
    stopSpeaking();
    setStatusMsg(`Call #${callId} ended`);
  };

  const addDemoCall = () => {
    const id = ++callIdCounter;
    const demoItems = [
      { name: 'Chicken Biryani', qty: 2, price: 240, total: 480 },
      { name: 'Cold Drink', qty: 3, price: 60, total: 180 },
    ];
    setCalls(prev => [...prev, {
      id, label: `Demo Call #${id}`,
      status: 'completed',
      items: demoItems,
      total: demoItems.reduce((s, i) => s + i.total, 0),
      stream: null, audioCtx: null, analyser: null, transcript: '',
    }]);
    setStatusMsg(`Demo order #${id} shown`);
  };

  const handleCheckUpdates = async () => {
    setUpdateModalOpen(true);
    setUpdateData({ currentVersion: APP_VERSION, latestVersion: '', progress: 0, status: 'checking', ready: false });
    if (window.api) {
      try {
        const r = await window.api.checkForUpdates();
        if (r.hasUpdate) {
          setUpdateData({
            currentVersion: APP_VERSION,
            latestVersion: r.latestVersion || '2.1.0',
            progress: 100,
            status: 'ready',
            ready: true,
            downloadUrl: r.downloadUrl
          });
        } else {
          setUpdateData({
            currentVersion: APP_VERSION,
            latestVersion: APP_VERSION,
            progress: 100,
            status: 'ready',
            ready: true,
            message: 'You are on the latest version'
          });
        }
      } catch (e) {
        setUpdateData({
          currentVersion: APP_VERSION,
          latestVersion: APP_VERSION,
          progress: 100,
          status: 'error',
          ready: false,
          message: 'Failed to check for updates'
        });
      }
    }
  };

  const handleApplyUpdate = () => {
    if (window.api) window.api.applyUpdate();
  };

  const activeCalls = calls.filter(c => c.status === 'active' || c.status === 'connecting');
  const completedCalls = calls.filter(c => c.status === 'completed' || c.status === 'error');

  return (
    <div className="h-screen w-screen bg-[#f5f0e8] flex flex-col select-none" style={{ fontFamily: 'Segoe UI, system-ui, sans-serif' }}>
      {restaurantStatus === 'maintenance' && (
        <div className="bg-amber-50 border-b border-amber-300 px-5 py-2 text-amber-800 text-xs font-bold text-center">
          🔧 MAINTENANCE MODE - Restaurant is paused for maintenance
        </div>
      )}

      {/* Top bar */}
      <div className="bg-white border-b border-[#ddd] px-5 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <span className="text-lg">🍗</span>
          <span className="font-bold text-[#333] text-sm">Azeem Pakwan</span>
          <span className={`heartbeat-dot ${restaurantStatus === 'running' ? 'active' : 'inactive'}`} title={restaurantStatus === 'running' ? 'Heartbeat active' : 'Heartbeat stopped'}></span>
          <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${phoneConnected ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>
            {phoneConnected ? '📞 Phone' : '📵 No Phone'}
          </span>
          {activeCalls.length > 0 && (
            <span className="text-xs bg-[#e67800]/10 text-[#e67800] px-2 py-0.5 rounded-full font-bold animate-pulse">
              {activeCalls.length} active call{activeCalls.length > 1 ? 's' : ''}
            </span>
          )}
          <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${
            restaurantStatus === 'running' ? 'bg-green-100 text-green-700' :
            restaurantStatus === 'maintenance' ? 'bg-amber-100 text-amber-700' :
            'bg-red-100 text-red-600'
          }`}>
            {restaurantStatus === 'running' ? '● Running' :
             restaurantStatus === 'maintenance' ? '● Maintenance' : '● Stopped'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <button onClick={() => setShowMicMenu(!showMicMenu)}
              className="px-3 py-1.5 text-xs bg-[#f5f0e8] border border-[#ddd] rounded-lg hover:bg-white">
              🎤 {micDevices.find(d => d.deviceId === selectedMic)?.label?.slice(0, 12) || 'Mic'}..
            </button>
            {showMicMenu && (
              <div className="absolute right-0 top-full mt-1 bg-white border border-[#ddd] rounded-xl shadow-lg z-50 w-64 max-h-40 overflow-y-auto">
                {micDevices.length === 0 && <div className="p-3 text-xs text-[#888]">No mics found</div>}
                {micDevices.map(d => (
                  <button key={d.deviceId} onClick={() => { setSelectedMic(d.deviceId); setShowMicMenu(false); }}
                    className={`block w-full text-left px-4 py-2 text-xs hover:bg-[#f5f0e8] border-b border-[#eee] ${d.deviceId === selectedMic ? 'bg-[#f5f0e8] font-bold' : ''}`}>
                    {d.label || 'Microphone'}
                  </button>
                ))}
              </div>
            )}
          </div>
          <button onClick={addCall} disabled={activeCalls.length >= 5}
            className="px-4 py-1.5 text-xs font-bold rounded-lg bg-[#e67800] text-white hover:opacity-90 disabled:opacity-40">
            + New Call
          </button>
          <button onClick={addDemoCall}
            className="px-3 py-1.5 text-xs bg-[#f5f0e8] border border-[#ddd] rounded-lg hover:bg-white">
            Demo
          </button>
          <button onClick={onToggleStatus}
            className="px-3 py-1.5 text-xs font-bold rounded-lg bg-[#333] text-white hover:opacity-90"
            title={restaurantStatus === 'running' ? 'Stop restaurant' : 'Start restaurant'}>
            {restaurantStatus === 'running' ? '⏹ Stop' : '▶ Start'}
          </button>
        </div>
      </div>

      {/* Status */}
      {statusMsg && (
        <div className="bg-[#e67800]/10 text-[#e67800] text-xs font-bold px-5 py-1.5 text-center border-b border-[#e67800]/20">
          {statusMsg}
        </div>
      )}

      {/* Menu warning */}
      {menuImages.length === 0 && (
        <div className="bg-amber-50 text-amber-700 text-xs px-5 py-1.5 text-center border-b border-amber-200">
          📷 No menu images. Drop menu photos in menu_images folder next to the EXE.
        </div>
      )}

      {/* Gemini key warning */}
      {!geminiKey && (
        <div className="bg-red-50 text-red-600 text-xs px-5 py-1.5 text-center border-b border-red-200 font-bold">
          ⚠️ No Gemini API key. Admin must add it via the Admin Panel (⚙) or SQL.
        </div>
      )}

      {/* Main — dynamic call rows */}
      <div className="flex-1 overflow-auto p-4">
        <div className="max-w-6xl mx-auto">
          {calls.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-20">
              <span className="text-5xl mb-4">📞</span>
              <h2 className="text-[#333] font-bold text-lg mb-2">No active calls</h2>
              <p className="text-[#888] text-sm max-w-md">Click <strong>"+ New Call"</strong> to start an AI-powered call. Each call gets its own row. Up to 5 simultaneous calls.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {calls.map(call => (
                <div key={call.id} className={`bg-white rounded-xl border shadow-sm overflow-hidden ${
                  call.status === 'active' ? 'border-[#e67800]' :
                  call.status === 'completed' ? 'border-green-300' :
                  call.status === 'error' ? 'border-red-300' : 'border-[#ddd]'
                }`}>
                  {/* Call header */}
                  <div className={`px-4 py-2.5 flex items-center justify-between ${
                    call.status === 'active' ? 'bg-[#e67800] text-white' :
                    call.status === 'completed' ? 'bg-green-100 text-green-800' :
                    call.status === 'error' ? 'bg-red-100 text-red-800' :
                    'bg-[#f5f0e8] text-[#888]'
                  }`}>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">{call.label}</span>
                      {call.status === 'active' && (
                        <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full animate-pulse">🔴 Live</span>
                      )}
                      {call.status === 'completed' && <span className="text-xs text-green-600">✓ Done</span>}
                      {call.status === 'error' && <span className="text-xs text-red-600">✕ Error</span>}
                    </div>
                    {(call.status === 'active' || call.status === 'connecting') && (
                      <button onClick={() => endCall(call.id)}
                        className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg font-bold">
                        End
                      </button>
                    )}
                  </div>

                  {/* Items */}
                  <div className="p-3">
                    {call.status === 'connecting' && (
                      <div className="text-[#888] text-xs text-center py-3 animate-pulse">Connecting...</div>
                    )}
                    {call.status === 'active' && call.items.length === 0 && (
                      <div className="text-[#ccc] text-xs text-center py-3 italic">Waiting for order...</div>
                    )}
                    {call.error && (
                      <div className="text-red-600 text-xs text-center py-2">{call.error}</div>
                    )}
                    {call.items.length > 0 && (
                      <div className="space-y-1.5">
                        {call.items.map((item, i) => (
                          <div key={i} className="bg-[#f5f0e8] rounded-lg px-3 py-2 flex items-center justify-between">
                            <div>
                              <span className="font-bold text-sm text-[#333]">{item.name}</span>
                              <span className="text-[#888] text-xs ml-2">×{item.qty}</span>
                            </div>
                            <span className="text-[#e67800] font-bold text-sm">Rs. {item.total || item.price * item.qty}</span>
                          </div>
                        ))}
                        <div className="flex justify-between px-3 py-1.5 font-bold text-sm border-t border-[#ddd]">
                          <span className="text-[#888]">Total</span>
                          <span className="text-[#e67800]">Rs. {call.items.reduce((s, i) => s + (i.total || i.price * i.qty), 0)}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="bg-white border-t border-[#ddd] px-5 py-2 text-[10px] text-[#aaa] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <span>v{APP_VERSION}</span>
          <span>·</span>
          <span>{calls.length} call{calls.length !== 1 ? 's' : ''} · {activeCalls.length} active</span>
        </div>
        <div className="flex items-center gap-3">
          <span>{menuImages.length} menu img</span>
          <span>·</span>
          <span className={geminiKey ? 'text-green-600' : 'text-red-500'}>
            {geminiKey ? '✓ AI key' : '⚠ No AI key'}
          </span>
          <button onClick={handleCheckUpdates}
            className="px-2 py-0.5 text-[10px] bg-[#f5f0e8] border border-[#ddd] rounded hover:bg-white font-bold text-[#666]">
            Check Updates
          </button>
          <button onClick={() => setAdminPanelOpen(!adminPanelOpen)}
            className="px-2 py-0.5 text-[10px] bg-[#f5f0e8] border border-[#ddd] rounded hover:bg-white text-[#666]"
            title="Admin Settings">
            ⚙
          </button>
        </div>
      </div>

      {/* Admin Panel */}
      {adminPanelOpen && (
        <AdminPanel onClose={() => setAdminPanelOpen(false)} />
      )}

      {/* Update Modal */}
      {updateModalOpen && updateData && (
        <UpdateModal
          data={updateData}
          onApply={handleApplyUpdate}
          onClose={() => setUpdateModalOpen(false)}
        />
      )}
    </div>
  );
}