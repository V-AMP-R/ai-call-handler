import { useState } from 'react';

export default function ActivationScreen({ onActivated }) {
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const handleRegister = async () => {
    if (!otp.trim() || !name.trim() || !location.trim()) { setError('Fill all fields'); return; }
    setBusy(true); setError('');
    try {
      const r = await window.api.register(name.trim(), location.trim(), otp.trim().toUpperCase());
      if (r.status === 'OK') onActivated();
      else setError(r.message || 'Wrong code or server error. Contact admin.');
    } catch (e) {
      const msg = e.message || '';
      if (msg.includes('register_client') || msg.includes('function') || msg.includes('relation'))
        setError('Server setup issue. Ask admin to run the SQL file.');
      else if (msg.includes('fetch') || msg.includes('network') || msg.includes('ENOTFOUND'))
        setError('Cannot reach server. Check internet connection.');
      else
        setError('Enter valid activation code from admin.');
    }
    setBusy(false);
  };

  return (
    <div className="h-screen w-screen bg-[#f5f0e8] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-lg border border-[#ddd] p-8 w-full max-w-sm">
        <div className="text-center mb-5">
          <span className="text-4xl">🍗</span>
          <h1 className="text-[#e67800] font-bold text-xl mt-1">Azeem Pakwan</h1>
          <p className="text-[#888] text-xs mt-1">Ask admin for the activation code</p>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-4 text-xs text-blue-700 leading-relaxed">
          Your admin has a code that changes every 60 seconds. Ask them for the current code, enter it below along with your restaurant details.
        </div>

        <input value={otp} onChange={e => setOtp(e.target.value.toUpperCase())}
          placeholder="Activation code from admin"
          className="w-full bg-[#f5f0e8] border border-[#ddd] rounded-xl px-4 py-3 text-sm text-center font-bold tracking-widest mb-3 focus:outline-none focus:border-[#e67800]" />
        <input value={name} onChange={e => setName(e.target.value)}
          placeholder="Restaurant name"
          className="w-full bg-[#f5f0e8] border border-[#ddd] rounded-xl px-4 py-3 text-sm mb-3 focus:outline-none focus:border-[#e67800]" />
        <input value={location} onChange={e => setLocation(e.target.value)}
          placeholder="Location / address"
          className="w-full bg-[#f5f0e8] border border-[#ddd] rounded-xl px-4 py-3 text-sm mb-4 focus:outline-none focus:border-[#e67800]" />

        {error && <div className="bg-red-50 text-red-600 text-xs font-bold px-3 py-2 rounded-xl mb-3 text-center">{error}</div>}

        <button onClick={handleRegister} disabled={busy}
          className="w-full py-3 bg-[#e67800] text-white font-bold rounded-xl hover:bg-[#d06c00] disabled:opacity-50">
          {busy ? 'Activating...' : '🔓 Activate'}
        </button>

        <p className="text-center text-[#aaa] text-xs mt-5">Hardware-locked to this PC. License cannot be copied.</p>
      </div>
    </div>
  );
}
