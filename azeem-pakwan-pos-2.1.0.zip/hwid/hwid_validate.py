"""
Azeem Pakwan Hardware Lock
- Extracts motherboard serial number via WMIC
- Validates against secure license key
- Obfuscated with PyArmor during build
"""
import os
import sys
import json
import hashlib
import base64
import subprocess
import platform
from pathlib import Path
from typing import Optional, Tuple

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


class HardwareLock:
    """Hardware license validation - obfuscate this with PyArmor"""
    
    def __init__(self):
        self.app_dir = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))
        self.license_file = self.app_dir / "license.key"
        self.hwid_hash = None
        self.supabase_url = None
        self.supabase_key = None
    
    def configure(self, supabase_url: str, supabase_key: str):
        """Set Supabase connection for online validation"""
        self.supabase_url = supabase_url
        self.supabase_key = supabase_key
    
    def get_motherboard_serial(self) -> Optional[str]:
        """Extract motherboard serial using WMIC"""
        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["wmic", "baseboard", "get", "serialnumber"],
                    capture_output=True, text=True, check=True, timeout=10
                )
                lines = result.stdout.strip().split("\n")
                if len(lines) >= 2:
                    serial = lines[1].strip()
                    if serial and serial != "To be filled by O.E.M.":
                        return serial
            
            # Fallback: use system UUID
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["wmic", "csproduct", "get", "uuid"],
                    capture_output=True, text=True, check=True, timeout=10
                )
                lines = result.stdout.strip().split("\n")
                if len(lines) >= 2:
                    return lines[1].strip()
            
            # Last resort fallback
            return f"{platform.node()}-{platform.machine()}"
            
        except (subprocess.SubProcessError, FileNotFoundError) as e:
            print(f"Error getting HWID: {e}")
            return None
    
    def compute_hwid_hash(self, serial: str) -> str:
        """Create SHA-256 hash of the hardware serial"""
        salt = "AzeemPakwan2024!@#$SecureSalt"
        combined = serial + salt + platform.node()
        return hashlib.sha256(combined.encode()).hexdigest()
    
    def generate_license_key(self, hwid_hash: str, client_id: str) -> str:
        """Generate a secure license key from HWID hash (for admin use)"""
        raw = f"{hwid_hash}:{client_id}:AzeemPakwanSecretKey2024"
        return base64.b64encode(raw.encode()).decode()
    
    def validate_license_key(self, license_key: str, hwid_hash: str) -> bool:
        """Validate a license key against current HWID"""
        try:
            decoded = base64.b64decode(license_key.encode()).decode()
            stored_hash, client_id, _ = decoded.split(":", 2)
            return stored_hash == hwid_hash
        except Exception:
            return False
    
    def online_validation(self, hwid_hash: str) -> dict:
        """Validate license against Supabase server"""
        if not self.supabase_url or not self.supabase_key:
            return {"valid": False, "reason": "No Supabase configured"}
        
        if not REQUESTS_AVAILABLE:
            return {"valid": False, "reason": "Requests library not available"}
        
        try:
            response = requests.post(
                f"{self.supabase_url}/rest/v1/rpc/validate_license",
                headers={
                    "apikey": self.supabase_key,
                    "Authorization": f"Bearer {self.supabase_key}",
                    "Content-Type": "application/json"
                },
                json={"hwid_hash_input": hwid_hash},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return {"valid": False, "reason": f"Server error: {response.status_code}"}
                
        except requests.exceptions.ConnectionError:
            return {"valid": False, "reason": "NO_INTERNET", "message": "Active internet connection required for license validation"}
        except requests.exceptions.Timeout:
            return {"valid": False, "reason": "TIMEOUT", "message": "License validation timed out"}
        except Exception as e:
            return {"valid": False, "reason": f"Error: {str(e)}"}
    
    def validate(self, use_online: bool = True) -> Tuple[bool, str]:
        """
        Main validation entry point.
        Returns (is_valid, message)
        """
        # Get hardware ID
        serial = self.get_motherboard_serial()
        if not serial:
            return False, "Could not read hardware serial"
        
        self.hwid_hash = self.compute_hwid_hash(serial)
        
        # Try online validation first
        if use_online:
            result = self.online_validation(self.hwid_hash)
            if result.get("valid"):
                return True, "License valid (online)"
            elif result.get("reason") == "NO_INTERNET":
                # Fallback to local license file validation
                return self._local_validation()
            else:
                return False, result.get("message", "License validation failed")
        
        # Local file validation
        return self._local_validation()
    
    def _local_validation(self) -> Tuple[bool, str]:
        """Validate against local license.key file"""
        if not self.license_file.exists():
            return False, "No license.key file found. Please activate Azeem Pakwan."
        
        try:
            with open(self.license_file, "r") as f:
                stored_key = f.read().strip()
            
            if self.validate_license_key(stored_key, self.hwid_hash):
                return True, "License valid (local)"
            else:
                return False, "License key mismatch. This PC is not authorized."
        except Exception as e:
            return False, f"License file error: {e}"
    
    def save_license(self, license_key: str):
        """Save license key to file"""
        with open(self.license_file, "w") as f:
            f.write(license_key)
    
    def get_hwid_info(self) -> dict:
        """Get hardware info for telemetry"""
        serial = self.get_motherboard_serial()
        return {
            "serial": serial,
            "hwid_hash": self.compute_hwid_hash(serial) if serial else None,
            "pc_name": platform.node(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "system": platform.system(),
            "release": platform.release()
        }


def main():
    """Main entry point for HWID validation"""
    lock = HardwareLock()
    
    # Check for command line args
    if len(sys.argv) > 1 and sys.argv[1] == "--generate":
        # Admin: Generate license key
        serial = lock.get_motherboard_serial()
        if not serial:
            print("Error: Cannot read hardware serial")
            sys.exit(1)
        
        hwid_hash = lock.compute_hwid_hash(serial)
        client_id = sys.argv[2] if len(sys.argv) > 2 else "CLIENT-001"
        license_key = lock.generate_license_key(hwid_hash, client_id)
        print(f"HWID Hash: {hwid_hash}")
        print(f"License Key: {license_key}")
        sys.exit(0)
    
    elif len(sys.argv) > 1 and sys.argv[1] == "--info":
        info = lock.get_hwid_info()
        print(json.dumps(info, indent=2))
        sys.exit(0)
    
    # Normal: Validate
    is_valid, message = lock.validate()
    
    if not is_valid:
        print(f"UNAUTHORIZED LICENSE")
        print(f"Reason: {message}")
        print(f"Please contact Azeem Pakwan support to activate your license.")
        sys.exit(1)
    
    print(f"LICENSE VALID")
    print(f"Welcome to Azeem Pakwan AI POS & Call Center")
    sys.exit(0)


if __name__ == "__main__":
    main()
