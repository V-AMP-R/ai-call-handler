"""
Azeem Pakwan License Key Generator
For admin use only - generates HWID-bound license keys
"""
import sys
import json
from hwid_validate import HardwareLock

def generate_client_license(client_id: str, hwid_hash: str = None):
    lock = HardwareLock()
    
    if not hwid_hash:
        # Generate from this machine (for development)
        serial = lock.get_motherboard_serial()
        hwid_hash = lock.compute_hwid_hash(serial)
    
    license_key = lock.generate_license_key(hwid_hash, client_id)
    
    license_data = {
        "client_id": client_id,
        "hwid_hash": hwid_hash,
        "license_key": license_key,
        "generated_at": __import__('datetime').datetime.now().isoformat(),
        "notes": "Store this license key securely. One license per machine."
    }
    
    return license_data

def batch_generate(config_file: str):
    """Generate licenses from a JSON config file"""
    with open(config_file, 'r') as f:
        clients = json.load(f)
    
    results = []
    for client in clients:
        license_data = generate_client_license(
            client.get('client_id'),
            client.get('hwid_hash')
        )
        results.append(license_data)
        print(f"Generated license for {client['client_id']}: {license_data['license_key']}")
    
    # Save to file
    output_file = "generated_licenses.json"
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nLicenses saved to {output_file}")
    
    return results

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "--batch" and len(sys.argv) > 2:
            batch_generate(sys.argv[2])
        else:
            client_id = sys.argv[1]
            hwid_hash = sys.argv[2] if len(sys.argv) > 2 else None
            result = generate_client_license(client_id, hwid_hash)
            print(json.dumps(result, indent=2))
    else:
        print("Usage:")
        print("  python license_server.py <client_id> [hwid_hash]")
        print("  python license_server.py --batch <config.json>")
        print("")
        print("To get HWID hash from client machine:")
        print("  python hwid_validate.py --info")
