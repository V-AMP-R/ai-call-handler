const https = require('https');
const http = require('http');

const SUPABASE_URL = 'https://wqnfentunekqkhowddcp.supabase.co';
const SUPABASE_KEY = 'sb_secret_pnMFX4QqHgS3fUdb61u9bA_tUUJyoK5';

function rpc(name, params = {}) {
  return new Promise(resolve => {
    const url = new URL(SUPABASE_URL + '/rest/v1/rpc/' + name);
    const client = url.protocol === 'https:' ? https : http;
    const body = JSON.stringify(params);
    const req = client.request(url, {
      method: 'POST',
      headers: { apikey: SUPABASE_KEY, Authorization: 'Bearer ' + SUPABASE_KEY, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      timeout: 15000,
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve({ ok: res.statusCode < 400, data: JSON.parse(d) }); } catch { resolve({ ok: false, data: d }); } });
    });
    req.on('error', e => resolve({ ok: false, error: e.message }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'TIMEOUT' }); });
    req.write(body);
    req.end();
  });
}

module.exports = {
  registerClient: (hwid, name, address, otp) => rpc('register_client', { p_hwid: hwid, p_name: name, p_address: address, p_otp: otp }),
  validateClient: (hwid) => rpc('validate_client', { p_hwid: hwid }),
  transferClient: (id, newHwid, otp) => rpc('transfer_client', { p_id: id, p_new_hwid: newHwid, p_otp: otp }),
  heartbeat: (hwid) => rpc('heartbeat', { p_hwid: hwid }),
  stopRestaurant: (hwid) => rpc('stop_restaurant', { p_hwid: hwid }),
  startRestaurant: (hwid) => rpc('start_restaurant', { p_hwid: hwid }),
  getStatus: (hwid) => rpc('validate_client', { p_hwid: hwid }),
  cleanupInactive: () => rpc('cleanup_inactive_restaurants', {}),
  getAllRestaurants: () => rpc('get_all_restaurants', {}),
  setGeminiApiKey: (key, label) => rpc('set_gemini_api_key', { p_key: key, p_label: label || 'Default' }),
  getActiveGeminiKey: () => rpc('get_active_gemini_key', {}),
};