const updater = require('../updater/github_updater');
let pendingUpdate = null;

async function checkOnStartup(currentVersion) {
  try {
    const info = await updater.checkForUpdates(currentVersion);
    if (info && info.hasUpdate) {
      pendingUpdate = info;
      global.pendingUpdate = info;
      console.log('[Updater] Update available:', info.latestVersion);
      return info;
    } else {
      console.log('[Updater] App is up to date (v' + currentVersion + ')');
    }
  } catch (e) {
    console.log('[Updater] Update check failed:', e.message);
  }
  return null;
}

function showUpdateNotification(win) {
  if (pendingUpdate && win) {
    win.webContents.send('update-available', pendingUpdate);
  }
}

module.exports = { checkOnStartup, showUpdateNotification, getPendingUpdate: () => pendingUpdate };