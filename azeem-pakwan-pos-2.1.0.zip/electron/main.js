const { app, BrowserWindow, ipcMain, Notification, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { HardwareLock, generateGlobalOtp } = require('./hwid');
const db = require('./database');
const updater = require('../updater/github_updater');
const { checkOnStartup, showUpdateNotification } = require('./update_checker');

const isDev = !app.isPackaged;
let win, hwLock;
let geminiKeyInMemory = '';
let heartbeatInterval = null;
const APP_VERSION = '2.0.0';

async function fetchAndStoreGeminiKey(keyId) {
  if (!keyId) return '';
  const r = await db.getActiveGeminiKey();
  if (r.ok && r.data?.found && r.data.api_key) {
    geminiKeyInMemory = r.data.api_key;
    return geminiKeyInMemory;
  }
  return '';
}

app.whenReady().then(async () => {
  hwLock = new HardwareLock(isDev ? app.getAppPath() : process.resourcesPath, app.getPath('userData'));
  const lic = hwLock.checkLicense();

  if (lic && lic.valid && lic.clientId) {
    const r = await db.validateClient(hwLock.getInfo().hwidHash);
    if (r.ok && r.data?.valid) {
      await fetchAndStoreGeminiKey(r.data.gemini_api_key_id);
      startHeartbeat();
    }
  }

  checkOnStartup(APP_VERSION);
  createWindow();
});

function startHeartbeat() {
  if (heartbeatInterval) clearInterval(heartbeatInterval);
  if (!hwLock) return;
  const info = hwLock.getInfo();
  heartbeatInterval = setInterval(async () => {
    try { await db.heartbeat(info.hwidHash); } catch {}
  }, 5000);
}

function stopHeartbeat() {
  if (heartbeatInterval) { clearInterval(heartbeatInterval); heartbeatInterval = null; }
}

function sendUpdateProgress(data) {
  if (win && !win.isDestroyed()) {
    win.webContents.send('update-progress', data);
  }
}

function createWindow() {
  win = new BrowserWindow({
    width: 1000,
    height: 680,
    minWidth: 800,
    minHeight: 500,
    resizable: true,
    autoHideMenuBar: true,
    icon: path.join(app.getAppPath(), 'assets', 'icon.ico'),
    backgroundColor: '#f5f0e8',
    title: 'Azeem Pakwan',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  if (isDev) win.loadURL('http://localhost:5173');
  else win.loadFile(path.join(app.getAppPath(), 'dist', 'index.html'));

  win.on('close', (e) => {
    if (!global._allowClose) {
      e.preventDefault();
      win.hide();
    }
  });

  win.webContents.on('did-finish-load', () => {
    win.webContents.send('boot', { activationNeeded: false, hasGeminiKey: !!geminiKeyInMemory });
    showUpdateNotification(win);
    if (global.pendingUpdate) {
      win.webContents.send('update-available', global.pendingUpdate);
    }
  });
}

ipcMain.handle('get-hwid', () => hwLock?.getInfo() || null);
ipcMain.handle('check-license', () => hwLock?.checkLicense() || null);
ipcMain.handle('delete-license', () => {
  hwLock?.removeLicense();
  geminiKeyInMemory = '';
  stopHeartbeat();
  return true;
});
ipcMain.handle('get-gemini-key', () => geminiKeyInMemory);
ipcMain.handle('get-app-version', () => APP_VERSION);

ipcMain.handle('register', async (_, name, location, otp) => {
  if (!hwLock) return { status: 'ERROR', message: 'Hardware ID not available.' };
  try {
    const info = hwLock.getInfo();
    const r = await db.registerClient(info.hwidHash, name, location, otp);
    if (r.ok && (r.data?.status === 'REGISTERED' || r.data?.status === 'ACTIVE')) {
      hwLock.saveLicense(r.data.client_id);
      await fetchAndStoreGeminiKey(r.data.gemini_api_key_id);
      startHeartbeat();
      return { status: 'OK', clientId: r.data.client_id, hasGeminiKey: !!geminiKeyInMemory };
    }
    if (!r.ok) return { status: 'FAIL', message: 'Server error: ' + (typeof r.data === 'string' ? r.data.slice(0, 200) : JSON.stringify(r.data)) };
    return { status: 'FAIL', message: r.data?.message || 'Wrong activation code.' };
  } catch (e) {
    return { status: 'FAIL', message: 'Cannot connect to server.' };
  }
});

ipcMain.handle('validate', async () => {
  if (!hwLock) return { valid: false };
  const r = await db.validateClient(hwLock.getInfo().hwidHash);
  if (r.ok && r.data?.valid) {
    await fetchAndStoreGeminiKey(r.data.gemini_api_key_id);
    return { valid: true, ...r.data };
  }
  return { valid: false };
});

ipcMain.handle('transfer', async (_, clientId, otp) => {
  if (!hwLock) return { status: 'ERROR' };
  const r = await db.transferClient(clientId, hwLock.getInfo().hwidHash, otp);
  if (r.ok && r.data?.status === 'TRANSFERRED') {
    hwLock.saveLicense(clientId);
    await fetchAndStoreGeminiKey(r.data.gemini_api_key_id);
    startHeartbeat();
    return { status: 'OK' };
  }
  return { status: 'FAIL' };
});

ipcMain.handle('get-global-otp', () => generateGlobalOtp());

ipcMain.handle('get-menu-images', () => {
  const dir = path.join(isDev ? app.getAppPath() : process.resourcesPath, 'menu_images');
  if (!fs.existsSync(dir)) { fs.mkdirSync(dir, { recursive: true }); return []; }
  return fs.readdirSync(dir).filter(f => /\.(png|jpg|jpeg|gif|webp)$/i.test(f)).map(f => ({
    name: f,
    path: path.join(dir, f),
    url: 'file://' + path.join(dir, f).replace(/\\/g, '/'),
  }));
});

ipcMain.handle('select-menu-images', async () => {
  const result = await dialog.showOpenDialog(win, {
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp'] }],
  });
  if (result.canceled) return [];
  const dir = path.join(isDev ? app.getAppPath() : process.resourcesPath, 'menu_images');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const saved = [];
  for (const fp of result.filePaths) {
    const name = path.basename(fp);
    const dest = path.join(dir, name);
    fs.copyFileSync(fp, dest);
    saved.push({ name, path: dest, url: 'file://' + dest.replace(/\\/g, '/') });
  }
  return saved;
});

ipcMain.handle('delete-menu-image', (_, name) => {
  const dir = path.join(isDev ? app.getAppPath() : process.resourcesPath, 'menu_images');
  const fp = path.join(dir, name);
  if (fs.existsSync(fp)) { fs.unlinkSync(fp); return true; }
  return false;
});

ipcMain.handle('stop-restaurant', async () => {
  if (!hwLock) return { status: 'ERROR', message: 'No hardware ID.' };
  stopHeartbeat();
  const r = await db.stopRestaurant(hwLock.getInfo().hwidHash);
  return { status: r.ok ? 'OK' : 'FAIL', data: r.data };
});

ipcMain.handle('start-restaurant', async () => {
  if (!hwLock) return { status: 'ERROR', message: 'No hardware ID.' };
  const r = await db.startRestaurant(hwLock.getInfo().hwidHash);
  if (r.ok) startHeartbeat();
  return { status: r.ok ? 'OK' : 'FAIL', data: r.data };
});

ipcMain.handle('check-for-updates', async () => {
  return updater.checkForUpdates(APP_VERSION);
});

ipcMain.handle('apply-update', async (_, url) => {
  try {
    const zipPath = await updater.downloadUpdate(url, (p) => {
      sendUpdateProgress({ progress: p, status: 'downloading' });
    });
    sendUpdateProgress({ status: 'applying' });
    updater.applyUpdate(zipPath);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('cleanup-inactive', async () => {
  const r = await db.cleanupInactive();
  return { status: r.ok ? 'OK' : 'FAIL', data: r.data };
});

ipcMain.handle('set-gemini-key', async (_, key, label) => {
  if (!hwLock) return { status: 'ERROR' };
  const r = await db.setGeminiApiKey(key, label);
  if (r.ok) geminiKeyInMemory = key;
  return { status: r.ok ? 'OK' : 'FAIL', data: r.data };
});

ipcMain.handle('get-all-restaurants', async () => {
  const r = await db.getAllRestaurants();
  return { status: r.ok ? 'OK' : 'FAIL', data: r.data };
});

ipcMain.handle('check-status', async () => {
  if (!hwLock) return { status: 'ERROR', message: 'No hardware ID.' };
  const r = await db.validateClient(hwLock.getInfo().hwidHash);
  return { status: r.ok ? 'OK' : 'FAIL', data: r.data };
});

app.on('window-all-closed', () => {});
app.on('before-quit', () => { global._allowClose = true; });
app.on('activate', () => win?.show() || createWindow());