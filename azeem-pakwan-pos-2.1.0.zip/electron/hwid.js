const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const os = require('os');

const GLOBAL_OTP_SALT = 'AzeemPakwanGlobalSalt2024';

class HardwareLock {
  constructor(appDir, userDataDir) {
    this.appDir = appDir;
    this.userDataDir = userDataDir;
    if (!fs.existsSync(userDataDir)) fs.mkdirSync(userDataDir, { recursive: true });
    this.licenseFile = path.join(userDataDir, 'license.key');
    this.serial = this._getSerial();
    this.hwidHash = this._hash();
  }

  _getSerial() {
    try {
      const out = execSync('wmic baseboard get serialnumber', { encoding: 'utf8', timeout: 5000 });
      const s = out.split('\n').map(l => l.trim()).filter(Boolean).pop();
      if (s && s !== 'To be filled by O.E.M.' && s !== 'System Serial Number' && s !== 'Default string') return s;
    } catch {}
    try { return execSync('wmic cpu get processorid', { encoding: 'utf8', timeout: 3000 }).split('\n')[1]?.trim() || os.hostname(); } catch {}
    return os.hostname();
  }

  _hash() {
    return crypto.createHash('sha256').update(this.serial + '|' + os.hostname() + '|AzeemPakwanHWSalt').digest('hex');
  }

  getInfo() {
    return { serial: this.serial, hwidHash: this.hwidHash, pc: os.hostname() };
  }

  checkLicense() {
    try {
      if (!fs.existsSync(this.licenseFile)) return null;
      const data = fs.readFileSync(this.licenseFile, 'utf8').trim().split(':');
      return data[0] === this.hwidHash ? { valid: true, clientId: data[1] || null } : { valid: false, reason: 'HWID_MISMATCH' };
    } catch { return { valid: false, reason: 'ERROR' }; }
  }

  saveLicense(clientId) {
    fs.writeFileSync(this.licenseFile, this.hwidHash + ':' + clientId, 'utf8');
    return true;
  }

  removeLicense() { if (fs.existsSync(this.licenseFile)) fs.unlinkSync(this.licenseFile); }
}

function generateGlobalOtp() {
  const charsL = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const charsN = '23456789';
  const ts = Math.floor(Date.now() / 60000);
  const hsh = crypto.createHash('sha256').update(GLOBAL_OTP_SALT + ts).digest('hex');
  let otp = '';
  for (let i = 0; i < 4; i++) otp += charsL[parseInt(hsh.substring(i * 8, i * 8 + 8), 16) % charsL.length];
  for (let i = 0; i < 4; i++) otp += charsN[parseInt(hsh.substring(i * 8 + 32, i * 8 + 40), 16) % charsN.length];
  return otp;
}

function generateClientOtp(clientId) {
  const charsL = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const charsN = '23456789';
  const ts = Math.floor(Date.now() / 60000);
  const hsh = crypto.createHash('sha256').update(clientId + ts + 'AzeemPakwanClientSalt2024').digest('hex');
  let otp = '';
  for (let i = 0; i < 4; i++) otp += charsL[parseInt(hsh.substring(i * 8, i * 8 + 8), 16) % charsL.length];
  for (let i = 0; i < 4; i++) otp += charsN[parseInt(hsh.substring(i * 8 + 32, i * 8 + 40), 16) % charsN.length];
  return otp;
}

module.exports = { HardwareLock, generateGlobalOtp, generateClientOtp };
