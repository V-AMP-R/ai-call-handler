@echo off
title Azeem Pakwan AI POS & Call Center
color 0A

echo.
echo ============================================
echo   AZEEM PAKWAN AI POS ^& CALL CENTER
echo ============================================
echo.

:: Check Node.js
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed!
    echo Please install Node.js from https://nodejs.org
    pause
    exit /b 1
)

:: Install dependencies if needed
if not exist "frontend\node_modules" (
    echo [INFO] Installing frontend dependencies...
    cd frontend
    npm install
    cd ..
)

:: Start development server
echo [INFO] Starting Azeem Pakwan...
echo [INFO] Open http://localhost:5173 in your browser
echo [INFO] Press Ctrl+C to stop
echo.
cd frontend
npm run dev
pause
