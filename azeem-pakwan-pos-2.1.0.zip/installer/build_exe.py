#!/usr/bin/env python3
"""
Azeem Pakwan - Installer EXE Builder
Builds smart_installer.py into a single portable EXE using PyInstaller.
Usage: python installer/build_exe.py
Output: installer/dist/smart-installer.exe
"""
import os
import sys
import subprocess
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("build-exe")

ROOT_DIR = Path(__file__).parent.parent
SMART_INSTALLER = Path(__file__).parent / "smart_installer.py"
DIST_DIR = Path(__file__).parent / "dist"
BUILD_DIR = Path(__file__).parent / "build"
ICON_PATH = ROOT_DIR / "assets" / "icon.ico"

APP_NAME = "AzeemPakwanSmartInstaller"
APP_FILENAME = "smart-installer"


def check_dependencies():
    logger.info("Checking dependencies...")
    ok = True
    for cmd, name in [(sys.executable, "Python"), (f"{sys.executable} -m PyInstaller", "PyInstaller")]:
        try:
            result = subprocess.run(cmd.split() + ["--version"], capture_output=True, text=True, timeout=10)
            version = result.stdout.strip() or result.stderr.strip()
            logger.info(f"  {name}: {version.splitlines()[0]}")
        except FileNotFoundError:
            logger.error(f"  {name}: NOT FOUND")
            ok = False
    if not ok:
        logger.error("Please install PyInstaller: pip install pyinstaller")
        return False
    return True


def build():
    logger.info("=" * 60)
    logger.info("  Building Smart Installer EXE")
    logger.info("=" * 60)

    if not SMART_INSTALLER.exists():
        logger.error(f"smart_installer.py not found at {SMART_INSTALLER}")
        sys.exit(1)

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--name", APP_FILENAME,
        "--distpath", str(DIST_DIR),
        "--workpath", str(BUILD_DIR),
        "--clean",
        "--log-level", "WARN",
        "--strip",
    ]

    if ICON_PATH.exists():
        cmd += ["--icon", str(ICON_PATH)]

    cmd.append(str(SMART_INSTALLER))

    logger.info(f"Running PyInstaller...")
    result = subprocess.run(cmd, cwd=str(ROOT_DIR))

    if result.returncode != 0:
        logger.error(f"PyInstaller failed with code {result.returncode}")
        sys.exit(1)

    exe_path = DIST_DIR / f"{APP_FILENAME}.exe"
    if exe_path.exists():
        size_mb = exe_path.stat().st_size / (1024 * 1024)
        logger.info(f"  Output: {exe_path} ({size_mb:.1f} MB)")
        logger.info("Build successful!")
    else:
        logger.error(f"Expected EXE not found at {exe_path}")
        sys.exit(1)

    return exe_path


if __name__ == "__main__":
    if not check_dependencies():
        sys.exit(1)
    build()