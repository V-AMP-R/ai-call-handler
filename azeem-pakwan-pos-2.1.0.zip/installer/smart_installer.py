#!/usr/bin/env python3
"""
Azeem Pakwan Smart Installer (GitHub-based)
- Fresh install: downloads latest release ZIP from GitHub, installs to target dir
- Update existing: downloads latest release, compares version, replaces files, restarts app
- Single EXE built via PyInstaller; no system-specs, no AI model selection
"""
import os
import sys
import json
import time
import zipfile
import tempfile
import subprocess
import logging
import platform
import shutil
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("smart-installer")

APP_NAME = "AzeemPakwan"
APP_OWNER = "V-AMP-R"
APP_REPO = "ai-call-handler"
API_BASE = f"https://api.github.com/repos/{APP_OWNER}/{APP_REPO}"
RELEASES_URL = f"{API_BASE}/releases/latest"
USER_AGENT = "azeem-pakwan-smart-installer/2.0"
CURRENT_VERSION_FILE = "version.json"

INSTALL_DIRS = [
    Path(os.environ.get("LOCALAPPDATA", "")) / APP_NAME,
    Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / APP_NAME,
    Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / APP_NAME,
]

GITHUB_TOKEN = os.environ.get("GH_TOKEN", "")


def safe_request(url, headers=None):
    req_headers = {"User-Agent": USER_AGENT}
    if headers:
        req_headers.update(headers)
    req = Request(url, headers=req_headers)
    try:
        with urlopen(req, timeout=20) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except HTTPError as e:
        if e.code == 403 and "rate limit" in e.read().decode("utf-8", errors="ignore").lower():
            logger.error("GitHub API rate limit exceeded. Set GH_TOKEN env var.")
        raise
    except URLError as e:
        logger.error(f"Network error: {e.reason}")
        raise


def get_latest_release():
    try:
        data = safe_request(RELEASES_URL)
        tag = data.get("tag_name", "").lstrip("v")
        zipball_url = data.get("zipball_url")
        tarball_url = data.get("tarball_url")
        browser_download_url = None
        if data.get("assets"):
            browser_download_url = data["assets"][0].get("browser_download_url")
        if not browser_download_url:
            browser_download_url = data.get("zipball_url")

        if not browser_download_url:
            logger.error("No files available on GitHub releases. Cannot install.")
            return {"error": "No files available on GitHub releases.", "tag": tag, "version": tag}
        return {
            "tag": tag,
            "tag_name": data.get("tag_name", ""),
            "version": tag,
            "zipball_url": data.get("zipball_url"),
            "tarball_url": data.get("tarball_url"),
            "browser_download_url": browser_download_url,
            "zipball": data.get("zipball_url"),
            "notes": data.get("body", ""),
            "published_at": data.get("published_at", ""),
        }
    except Exception as e:
        logger.error(f"Failed to fetch latest release: {e}")
        return None


def download_file(url, dest, on_progress=None):
    req = Request(url, headers={"User-Agent": USER_AGENT})
    if GITHUB_TOKEN:
        req.add_header("Authorization", f"Bearer {GITHUB_TOKEN}")
    try:
        with urlopen(req, timeout=120) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            downloaded = 0
            with open(dest, "wb") as f:
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if on_progress and total > 0:
                        on_progress(min(100, round((downloaded / total) * 100)))
    except Exception as e:
        logger.error(f"Download failed: {e}")
        raise
    return dest


def find_install_dir():
    for d in INSTALL_DIRS:
        marker = d / "app" / "main.js"
        if marker.exists():
            logger.info(f"Existing installation found at: {d}")
            return d
    return None


def get_installed_version(install_dir):
    vf = install_dir / "app" / CURRENT_VERSION_FILE
    if vf.exists():
        try:
            with open(vf) as f:
                data = json.load(f)
            return data.get("latestVersion", "0.0.0")
        except Exception:
            pass
    return "0.0.0"


def fresh_install(target_dir, release_info):
    logger.info(f"Fresh install to: {target_dir}")
    target_dir.mkdir(parents=True, exist_ok=True)
    app_dir = target_dir / "app"
    app_dir.mkdir(exist_ok=True)

    zip_path = _download_and_extract(release_info, app_dir)
    _create_shortcuts(target_dir, app_dir)
    _write_version(target_dir, release_info)
    _cleanup_temp(zip_path)

    logger.info(f"Installed successfully to {target_dir}")
    logger.info(f"  Start: {target_dir / 'start.bat'}")


def update_install(install_dir, release_info):
    installed_ver = get_installed_version(install_dir)
    new_ver = release_info["version"]

    if installed_ver == new_ver:
        logger.info(f"Already at latest version v{new_ver}")
        return False

    logger.info(f"Updating v{installed_ver} -> v{new_ver}")
    app_dir = install_dir / "app"
    app_dir.mkdir(exist_ok=True)

    zip_path = _download_and_extract(release_info, app_dir)
    _write_version(install_dir, release_info)
    _cleanup_temp(zip_path)

    logger.info("Update applied. Restarting application...")
    _restart_app(install_dir)
    return True


def _download_and_extract(release_info, dest_dir):
    zip_url = release_info.get("browser_download_url") or release_info.get("zipball_url")
    if not zip_url:
        raise RuntimeError("No download URL found in release info")

    logger.info(f"Downloading release ZIP from GitHub...")

    tmp_zip = Path(tempfile.gettempdir()) / f"azeem-pakwan-install-{int(time.time())}.zip"
    tmp_zip.parent.mkdir(parents=True, exist_ok=True)

    def progress(pct):
        logger.info(f"  Download progress: {pct}%")

    download_file(zip_url, tmp_zip, progress)

    logger.info(f"Extracting to {dest_dir}...")
    with zipfile.ZipFile(tmp_zip, "r") as zf:
        members = zf.namelist()
        prefix = ""
        for m in members:
            parts = m.split("/")
            if len(parts) > 1:
                prefix = parts[0]
                break
        for member in members:
            if prefix and member.startswith(prefix + "/"):
                rel = member[len(prefix) + 1:]
            else:
                rel = member
            if not rel:
                continue
            src = zf.open(member)
            target = dest_dir / rel
            if member.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with open(target, "wb") as f:
                    f.write(src.read())

    return tmp_zip


def _write_version(install_dir, release_info):
    vf = install_dir / CURRENT_VERSION_FILE
    version_data = {
        "latestVersion": release_info["version"],
        "installDate": time.strftime("%Y-%m-%d %H:%M:%S"),
        "installedBy": "smart-installer",
    }
    with open(vf, "w") as f:
        json.dump(version_data, f, indent=2)


def _create_shortcuts(install_dir, app_dir):
    target_exe = app_dir / "dist" / "Azeem Pakwan.exe"
    if not target_exe.exists():
        unpacked = app_dir / "win-unpacked" / "Azeem Pakwan.exe"
        if unpacked.exists():
            target_exe = unpacked

    start_bat = install_dir / "start.bat"
    bat_content = f"""@echo off
echo Starting Azeem Pakwan...
cd /d "{install_dir}"
start "" "{target_exe}"
"""
    with open(start_bat, "w") as f:
        f.write(bat_content)

    desktop_shortcut = Path(os.path.join(os.environ.get("USERPROFILE", ""), "Desktop", "Azeem Pakwan.lnk"))
    if desktop_shortcut.parent.exists():
        _create_windows_shortcut(desktop_shortcut, target_exe, "Azeem Pakwan POS")

    logger.info("Shortcuts created")


def _create_windows_shortcut(link_path, target, description):
    try:
        import winshell
        from win32com.client import Dispatch
        shell = Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(str(link_path))
        shortcut.Targetpath = str(target)
        shortcut.Description = description
        shortcut.save()
    except ImportError:
        logger.info("winshell not available; skipping desktop shortcut")


def _restart_app(install_dir):
    try:
        app_exe = install_dir / "app" / "dist" / "Azeem Pakwan.exe"
        if not app_exe.exists():
            app_exe = install_dir / "app" / "win-unpacked" / "Azeem Pakwan.exe"
        if app_exe.exists():
            subprocess.Popen([str(app_exe), "--updated"], cwd=str(install_dir))
    except Exception as e:
        logger.warning(f"Could not restart app automatically: {e}")
        logger.info(f"Please run: {install_dir / 'start.bat'}")


def _cleanup_temp(zip_path):
    try:
        if zip_path and zip_path.exists():
            zip_path.unlink()
    except Exception:
        pass


def stop_running_app(install_dir):
    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"IMAGENAME eq Azeem Pakwan.exe", "/FO", "CSV"],
            capture_output=True, text=True, timeout=5,
        )
        for line in result.stdout.split("\n"):
            if "Azeem Pakwan" in line:
                pid = line.split(",")[1].strip('"') if "," in line else None
                if pid:
                    logger.info(f"Stopping running instance (PID {pid})...")
                    subprocess.run(["taskkill", "/PID", pid, "/F"], capture_output=True, timeout=10)
                    time.sleep(1)
    except Exception as e:
        logger.warning(f"Could not stop running instance: {e}")


def run_installer():
    logger.info("=" * 60)
    logger.info("  AZEEM PAKWAN - SMART INSTALLER")
    logger.info("  GitHub-based installer for Windows")
    logger.info("=" * 60)

    force_fresh = "--fresh" in sys.argv
    target = INSTALL_DIRS[0]

    if "--target" in sys.argv:
        idx = sys.argv.index("--target")
        if idx + 1 < len(sys.argv):
            target = Path(sys.argv[idx + 1])
        logger.info(f"Install to: {target}")
    elif force_fresh and len(sys.argv) > 1:
        try:
            idx = sys.argv.index("--fresh")
            if idx + 1 < len(sys.argv) and not sys.argv[idx + 1].startswith("-"):
                target = Path(sys.argv[idx + 1])
        except (ValueError, IndexError):
            pass
        logger.info(f"Fresh install to: {target}")
    else:
        existing = find_install_dir()
        if existing:
            target = existing
            logger.info(f"Existing installation found at: {target}")
        else:
            logger.info(f"No existing install found. Installing to: {target}")

    release_info = get_latest_release()
    if not release_info:
        logger.error("Cannot find latest release on GitHub.")
        sys.exit(1)

    logger.info(f"Latest release: v{release_info['version']}")

    download_url = release_info.get("browser_download_url") or release_info.get("zipball_url")
    if not download_url:
        logger.error("Cannot install: no downloadable files found on GitHub releases.")
        logger.error("The release may be empty or the network connection failed.")
        sys.exit(1)

    if force_fresh:
        logger.info("Forcing fresh install (overwrite mode).")
        stop_running_app(target)
        time.sleep(1)
        fresh_install(target, release_info)
        logger.info("Installation complete!")
    elif find_install_dir():
        existing = find_install_dir()
        stop_running_app(existing)
        time.sleep(1)
        updated = update_install(existing, release_info)
        if updated:
            logger.info("Update complete!")
        else:
            logger.info("No update needed - you are already at the latest version.")
    else:
        stop_running_app(target)
        time.sleep(1)
        fresh_install(target, release_info)
        logger.info("Installation complete!")

    logger.info("Done.")


if __name__ == "__main__":
    run_installer()