import time
import subprocess

# Start server
server_proc = subprocess.Popen([
    'python', 'updater/update_server.py', 
    '--releases-dir', 'updater/releases', 
    '--port', '8080', 
    '--admin-key', 'test123'
], cwd=r'F:\USER_DATA\WAJEEH\Documents\Default Project\azeem-pakwan-pos')

time.sleep(3)

# Test endpoints
import urllib.request
import json

try:
    # Test version.json
    with urllib.request.urlopen('http://localhost:8080/version.json') as response:
        data = json.load(response)
        print('version.json:', json.dumps(data, indent=2))
    
    # Test health
    with urllib.request.urlopen('http://localhost:8080/health') as response:
        print('health:', json.load(response))
        
finally:
    server_proc.terminate()
    server_proc.wait()