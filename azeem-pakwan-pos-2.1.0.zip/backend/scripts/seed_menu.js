const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const menuItems = [
  { name: 'Chicken Tikka', name_urdu: 'چکن تکہ', category: 'BBQ', price_pkr: 350, description: '4 pieces of tender chicken tikka with herbs' },
  { name: 'Beef Bihari Kabab', name_urdu: 'بیف بہاری کباب', category: 'BBQ', price_pkr: 420, description: '2 pieces of traditional Bihari style beef kabab' },
  { name: 'Seekh Kabab', name_urdu: 'سیخ کباب', category: 'BBQ', price_pkr: 380, description: '6 pieces of minced beef seekh kabab' },
  { name: 'Reshmi Kabab', name_urdu: 'ریشمی کباب', category: 'BBQ', price_pkr: 450, description: '4 pieces of creamy reshmi chicken kabab' },
  { name: 'Malai Boti', name_urdu: 'ملائی بوٹی', category: 'BBQ', price_pkr: 480, description: '6 pieces of creamy malai chicken boti' },
  { name: 'Family Platter', name_urdu: 'فیملی پلیٹر', category: 'DEALS', price_pkr: 1850, description: '12 pcs mixed BBQ + 2 naan + raita + salad' },
  { name: 'Mighty Zinger', name_urdu: 'مائیٹی زنگر', category: 'DEALS', price_pkr: 650, description: 'Crispy chicken burger with fries and drink' },
  { name: 'Zinger Stacker', name_urdu: 'زنگر اسٹیکر', category: 'DEALS', price_pkr: 750, description: 'Double decker zinger with extra cheese' },
  { name: 'Crispy Duo', name_urdu: 'کرنسی ڈیو', category: 'DEALS', price_pkr: 890, description: '2 zinger burgers + 2 fries + 2 drinks' },
  { name: 'Mega Feast', name_urdu: 'میگا فیسٹ', category: 'DEALS', price_pkr: 1450, description: '4 zingers + 4 fries + 4 drinks + nuggets' },
  { name: 'Student Special', name_urdu: 'اسٹوڈنٹ اسپیشل', category: 'DEALS', price_pkr: 320, description: '1 zinger + fries + drink (student discount)' },
  { name: 'Beef Biryani Daig', name_urdu: 'بیف بریانی دیگ', category: 'DAIG_CATERING', price_pkr: 4500, description: 'Full daig beef biryani (serves 15-20)' },
  { name: 'Degi Korma', name_urdu: 'دیگی کورمہ', category: 'DAIG_CATERING', price_pkr: 3800, description: 'Full daig chicken/beef korma (serves 15-20)' },
  { name: 'Chicken Pulao Daig', name_urdu: 'چکن پلاؤ دیگ', category: 'DAIG_CATERING', price_pkr: 3200, description: 'Full daig chicken pulao (serves 15-20)' },
  { name: 'Nihabi Daig', name_urdu: 'نہاری دیگ', category: 'DAIG_CATERING', price_pkr: 5000, description: 'Full daig beef nihari (serves 15-20)' },
  { name: 'Haleem Daig', name_urdu: 'حلیم دیگ', category: 'DAIG_CATERING', price_pkr: 4200, description: 'Full daig chicken/beef haleem (serves 15-20)' },
  { name: 'Mixed Daig', name_urdu: 'مکسڈ دیگ', category: 'DAIG_CATERING', price_pkr: 6000, description: 'Half biryani + half korma daig (serves 15-20)' },
];

async function seed() {
  const { data, error } = await supabase.from('menu_items').upsert(menuItems, { onConflict: 'name' });
  if (error) console.error('Seed error:', error);
  else console.log('Seeded', data.length, 'menu items');
}

seed();
