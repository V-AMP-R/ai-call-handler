-- =====================================================
-- STEP 1 OF 2: Drop everything safely
-- Run this FIRST in Supabase SQL Editor
-- Safe for fresh databases (no tables exist yet)
-- =====================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Functions only (no table references = safe)
DROP FUNCTION IF EXISTS prevent_delete_if_recent() CASCADE;
DROP FUNCTION IF EXISTS fn_prevent_delete() CASCADE;
DROP FUNCTION IF EXISTS generate_client_otp(UUID) CASCADE;
DROP FUNCTION IF EXISTS refresh_client_otp(UUID) CASCADE;
DROP FUNCTION IF EXISTS refresh_all_otps() CASCADE;
DROP FUNCTION IF EXISTS generate_global_otp() CASCADE;
DROP FUNCTION IF EXISTS register_client(VARCHAR, VARCHAR, VARCHAR, VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS transfer_client(UUID, VARCHAR, VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS validate_client(VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS heartbeat(VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS stop_restaurant(VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS start_restaurant(VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS cleanup_inactive_restaurants() CASCADE;
DROP FUNCTION IF EXISTS get_all_restaurants() CASCADE;
DROP FUNCTION IF EXISTS set_gemini_api_key(VARCHAR, VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS get_active_gemini_key() CASCADE;

-- Tables (safe even if they don't exist)
DROP TABLE IF EXISTS restaurants CASCADE;
DROP TABLE IF EXISTS gemini_api_keys CASCADE;
DROP TABLE IF EXISTS clients CASCADE;