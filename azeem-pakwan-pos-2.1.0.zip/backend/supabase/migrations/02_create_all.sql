-- =====================================================
-- STEP 2 OF 2: Create everything fresh
-- Run this SECOND in Supabase SQL Editor
-- =====================================================

CREATE TABLE gemini_api_keys (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  api_key VARCHAR NOT NULL,
  label VARCHAR DEFAULT 'Default',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE gemini_api_keys DISABLE ROW LEVEL SECURITY;

CREATE TABLE restaurants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  restaurant_name VARCHAR NOT NULL,
  otp_code VARCHAR(8) DEFAULT '',
  hwid_hash VARCHAR UNIQUE,
  address VARCHAR NOT NULL,
  is_active BOOLEAN DEFAULT true,
  status VARCHAR DEFAULT 'running',
  installed_at TIMESTAMPTZ DEFAULT NOW(),
  last_heartbeat TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  gemini_api_key_id UUID REFERENCES gemini_api_keys(id) ON DELETE SET NULL
);
ALTER TABLE restaurants DISABLE ROW LEVEL SECURITY;
ALTER TABLE restaurants ADD CONSTRAINT chk_status CHECK (status IN ('running','maintenance','stopped'));

CREATE OR REPLACE FUNCTION generate_client_otp(pid UUID)
RETURNS VARCHAR(8) LANGUAGE plpgsql STABLE AS $$
DECLARE
  cl VARCHAR := 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  cn VARCHAR := '23456789';
  ts BIGINT; s TEXT; h VARCHAR; o VARCHAR := ''; i INT;
BEGIN
  ts := EXTRACT(EPOCH FROM NOW())::BIGINT / 60;
  s := pid::TEXT || ts::TEXT || 'AzeemPakwanClientSalt2024';
  h := encode(sha256(s::bytea), 'hex');
  FOR i IN 1..4 LOOP o := o || substr(cl, ((('x' || substr(h, (i-1)*8+1, 8))::bit(32))::int % length(cl)) + 1, 1); END LOOP;
  FOR i IN 1..4 LOOP o := o || substr(cn, ((('x' || substr(h, (i-1)*8+33, 8))::bit(32))::int % length(cn)) + 1, 1); END LOOP;
  RETURN o;
END;
$$;

CREATE OR REPLACE FUNCTION refresh_client_otp(pid UUID)
RETURNS VARCHAR(8) LANGUAGE plpgsql AS $$
DECLARE o VARCHAR(8);
BEGIN
  o := generate_client_otp(pid);
  UPDATE restaurants SET otp_code = o WHERE id = pid;
  RETURN o;
END;
$$;

CREATE OR REPLACE FUNCTION refresh_all_otps()
RETURNS INTEGER LANGUAGE plpgsql AS $$
DECLARE v_count INT;
BEGIN
  UPDATE restaurants SET otp_code = generate_client_otp(id) WHERE is_active = true;
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$;

CREATE OR REPLACE FUNCTION generate_global_otp()
RETURNS VARCHAR(8) LANGUAGE plpgsql STABLE AS $$
DECLARE
  cl VARCHAR := 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  cn VARCHAR := '23456789';
  ts BIGINT; s TEXT; h VARCHAR; o VARCHAR := ''; i INT;
BEGIN
  ts := EXTRACT(EPOCH FROM NOW())::BIGINT / 60;
  s := 'AzeemPakwanGlobalSalt2024' || ts::TEXT;
  h := encode(sha256(s::bytea), 'hex');
  FOR i IN 1..4 LOOP o := o || substr(cl, ((('x' || substr(h, (i-1)*8+1, 8))::bit(32))::int % length(cl)) + 1, 1); END LOOP;
  FOR i IN 1..4 LOOP o := o || substr(cn, ((('x' || substr(h, (i-1)*8+33, 8))::bit(32))::int % length(cn)) + 1, 1); END LOOP;
  RETURN o;
END;
$$;

CREATE OR REPLACE FUNCTION prevent_delete_if_recent()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.last_heartbeat >= NOW() - INTERVAL '120 seconds' THEN
    UPDATE restaurants SET is_active = false, status = 'stopped', otp_code = '' WHERE id = OLD.id;
    RETURN NULL;
  END IF;
  RETURN OLD;
END;
$$;

CREATE TRIGGER trigger_prevent_delete_if_recent
  BEFORE DELETE ON restaurants
  FOR EACH ROW EXECUTE FUNCTION prevent_delete_if_recent();

CREATE OR REPLACE FUNCTION register_client(p_hwid VARCHAR, p_name VARCHAR, p_address VARCHAR, p_otp VARCHAR)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  v_existing UUID;
  v_new_id UUID;
  v_key_id UUID;
BEGIN
  SELECT id INTO v_existing FROM restaurants WHERE hwid_hash = p_hwid;
  IF v_existing IS NOT NULL THEN
    UPDATE restaurants SET is_active = true, status = 'running', last_heartbeat = NOW(), otp_code = generate_client_otp(v_existing) WHERE id = v_existing;
    SELECT gemini_api_key_id INTO v_key_id FROM restaurants WHERE id = v_existing;
    RETURN json_build_object('status', 'ACTIVE', 'client_id', v_existing, 'gemini_api_key_id', v_key_id);
  END IF;
  IF p_otp != generate_global_otp() THEN
    RETURN json_build_object('status', 'INVALID_OTP', 'message', 'Wrong activation code.');
  END IF;
  SELECT id INTO v_key_id FROM gemini_api_keys WHERE is_active = true LIMIT 1;
  INSERT INTO restaurants (hwid_hash, restaurant_name, address, gemini_api_key_id)
  VALUES (p_hwid, p_name, p_address, v_key_id)
  RETURNING id INTO v_new_id;
  UPDATE restaurants SET otp_code = generate_client_otp(v_new_id) WHERE id = v_new_id;
  RETURN json_build_object('status', 'REGISTERED', 'client_id', v_new_id, 'gemini_api_key_id', v_key_id);
END;
$$;

CREATE OR REPLACE FUNCTION validate_client(p_hwid VARCHAR)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v restaurants%ROWTYPE;
BEGIN
  SELECT * INTO v FROM restaurants WHERE hwid_hash = p_hwid;
  IF NOT FOUND THEN RETURN json_build_object('valid', false, 'reason', 'NOT_FOUND'); END IF;
  IF NOT v.is_active THEN RETURN json_build_object('valid', false, 'reason', 'INACTIVE'); END IF;
  UPDATE restaurants SET otp_code = generate_client_otp(v.id) WHERE id = v.id;
  RETURN json_build_object('valid', true, 'client_id', v.id, 'restaurant_name', v.restaurant_name, 'status', v.status, 'gemini_api_key_id', v.gemini_api_key_id);
END;
$$;

CREATE OR REPLACE FUNCTION transfer_client(p_id UUID, p_new_hwid VARCHAR, p_otp VARCHAR)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_expected VARCHAR; v_key_id UUID;
BEGIN
  v_expected := refresh_client_otp(p_id);
  IF v_expected != p_otp THEN RETURN json_build_object('status', 'INVALID_OTP'); END IF;
  SELECT gemini_api_key_id INTO v_key_id FROM restaurants WHERE id = p_id;
  UPDATE restaurants SET hwid_hash = p_new_hwid, is_active = true, status = 'running', last_heartbeat = NOW() WHERE id = p_id;
  RETURN json_build_object('status', 'TRANSFERRED', 'client_id', p_id, 'gemini_api_key_id', v_key_id);
END;
$$;

CREATE OR REPLACE FUNCTION heartbeat(p_hwid VARCHAR)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE restaurants SET last_heartbeat = NOW(), is_active = true, status = 'running' WHERE hwid_hash = p_hwid;
  RETURN json_build_object('ok', true);
END;
$$;

CREATE OR REPLACE FUNCTION stop_restaurant(p_hwid VARCHAR)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE restaurants SET status = 'maintenance', is_active = false WHERE hwid_hash = p_hwid;
  RETURN json_build_object('ok', true, 'status', 'maintenance');
END;
$$;

CREATE OR REPLACE FUNCTION start_restaurant(p_hwid VARCHAR)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE restaurants SET status = 'running', is_active = true, last_heartbeat = NOW() WHERE hwid_hash = p_hwid;
  RETURN json_build_object('ok', true, 'status', 'running');
END;
$$;

CREATE OR REPLACE FUNCTION cleanup_inactive_restaurants()
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_count INT;
BEGIN
  DELETE FROM restaurants WHERE last_heartbeat < NOW() - INTERVAL '60 seconds' AND status = 'stopped';
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN json_build_object('ok', true, 'deleted', v_count);
END;
$$;

CREATE OR REPLACE FUNCTION get_all_restaurants()
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_result JSON;
BEGIN
  SELECT COALESCE(json_agg(row_to_json(r.*)), '[]'::json) INTO v_result FROM restaurants r;
  RETURN v_result;
END;
$$;

CREATE OR REPLACE FUNCTION set_gemini_api_key(p_key VARCHAR, p_label VARCHAR DEFAULT 'Default')
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_id UUID;
BEGIN
  SELECT id INTO v_id FROM gemini_api_keys WHERE label = p_label;
  IF FOUND THEN
    UPDATE gemini_api_keys SET api_key = p_key, is_active = true WHERE label = p_label;
  ELSE
    INSERT INTO gemini_api_keys (api_key, label) VALUES (p_key, p_label) RETURNING id INTO v_id;
  END IF;
  RETURN json_build_object('ok', true, 'id', v_id);
END;
$$;

CREATE OR REPLACE FUNCTION get_active_gemini_key()
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v gemini_api_keys%ROWTYPE;
BEGIN
  SELECT * INTO v FROM gemini_api_keys WHERE is_active = true LIMIT 1;
  IF NOT FOUND THEN RETURN json_build_object('found', false); END IF;
  RETURN json_build_object('found', true, 'id', v.id, 'api_key', v.api_key, 'label', v.label);
END;
$$;

INSERT INTO gemini_api_keys (api_key, label, is_active)
VALUES ('YOUR_GEMINI_API_KEY_HERE', 'Default', true)
ON CONFLICT DO NOTHING;

INSERT INTO restaurants (restaurant_name, hwid_hash, address, gemini_api_key_id)
SELECT 'Admin Restaurant', 'ADMIN_HWID_TEST', 'Admin Address', id
FROM gemini_api_keys WHERE label = 'Default'
ON CONFLICT (hwid_hash) DO NOTHING;

NOTIFY pgrst, 'reload schema';