"""
Azeem Pakwan AI Voice Pipeline
- Whisper STT for Roman Urdu/English transcription
- LLM integration for order processing
- Structured JSON output mapping to cart state
"""
import os
import sys
import json
import logging
import tempfile
from pathlib import Path
from typing import Optional, Dict, Any
import requests

# Optional imports - gracefully fallback
try:
    import whisper
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False

try:
    import pyaudio
    PYAUDIO_AVAILABLE = True
except ImportError:
    PYAUDIO_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("azeem-ai")

SYSTEM_PROMPT = """You are the AI Digital Munshi for Azeem Pakwan. Differentiate between Fast Food orders and Daig bookings. Respond in friendly Roman Urdu. Return the final order as a structured JSON object containing items, total PKR, and customer address."""

class VoicePipeline:
    def __init__(self, model_size: str = "small", use_gpu: bool = False):
        self.model_size = model_size
        self.use_gpu = use_gpu
        self.model = None
        self.llm_endpoint = None
        self.llm_api_key = None
        self.is_ready = False
        
    def initialize_whisper(self):
        """Initialize Whisper STT model"""
        if not WHISPER_AVAILABLE:
            logger.warning("Whisper not installed. Using API fallback.")
            return False
        try:
            logger.info(f"Loading Whisper {self.model_size} model...")
            self.model = whisper.load_model(self.model_size, device="cuda" if self.use_gpu else "cpu")
            self.is_ready = True
            logger.info("Whisper model loaded successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to load Whisper: {e}")
            return False
    
    def set_llm_endpoint(self, endpoint: str, api_key: Optional[str] = None):
        """Configure LLM endpoint (local or API)"""
        self.llm_endpoint = endpoint
        self.llm_api_key = api_key
    
    def transcribe_audio(self, audio_path: str, language: str = "ur") -> Dict[str, Any]:
        """Transcribe audio file using Whisper"""
        if not self.model:
            return {"text": "", "error": "Whisper model not initialized"}
        
        try:
            result = self.model.transcribe(
                audio_path,
                language=language,
                task="transcribe",
                temperature=0.0,
                word_timestamps=True
            )
            return {
                "text": result["text"],
                "segments": result.get("segments", []),
                "language": result.get("language", "ur")
            }
        except Exception as e:
            logger.error(f"Transcription error: {e}")
            return {"text": "", "error": str(e)}
    
    def process_with_llm(self, transcript: str, llm_type: str = "groq") -> Dict[str, Any]:
        """Send transcript to LLM and get structured order JSON"""
        if llm_type == "groq":
            return self._query_groq(transcript)
        elif llm_type == "ollama":
            return self._query_ollama(transcript)
        elif llm_type == "openai":
            return self._query_openai(transcript)
        else:
            return self._query_groq(transcript)
    
    def _query_groq(self, transcript: str) -> Dict[str, Any]:
        """Query Groq API"""
        api_key = self.llm_api_key or os.getenv("GROQ_API_KEY")
        if not api_key:
            return {"error": "No Groq API key configured"}
        
        try:
            response = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "llama-3.3-70b-versatile",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": f"Customer said: {transcript}\n\nExtract order details and return JSON."}
                    ],
                    "temperature": 0.1,
                    "response_format": {"type": "json_object"}
                },
                timeout=30
            )
            response.raise_for_status()
            result = response.json()
            content = result["choices"][0]["message"]["content"]
            return json.loads(content)
        except Exception as e:
            logger.error(f"Groq API error: {e}")
            return {"error": str(e)}
    
    def _query_ollama(self, transcript: str) -> Dict[str, Any]:
        """Query local Ollama instance"""
        endpoint = self.llm_endpoint or "http://localhost:11434"
        try:
            response = requests.post(
                f"{endpoint}/api/chat",
                json={
                    "model": "llama3.1",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": f"Customer said: {transcript}\n\nExtract order JSON."}
                    ],
                    "stream": False,
                    "format": "json"
                },
                timeout=60
            )
            response.raise_for_status()
            result = response.json()
            return json.loads(result["message"]["content"])
        except Exception as e:
            logger.error(f"Ollama error: {e}")
            return {"error": str(e)}
    
    def _query_openai(self, transcript: str) -> Dict[str, Any]:
        """Query OpenAI API"""
        api_key = self.llm_api_key or os.getenv("OPENAI_API_KEY")
        if not api_key:
            return {"error": "No OpenAI API key configured"}
        
        try:
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "gpt-4o-mini",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": f"Customer said: {transcript}\n\nExtract order JSON."}
                    ],
                    "temperature": 0.1,
                    "response_format": {"type": "json_object"}
                },
                timeout=30
            )
            response.raise_for_status()
            result = response.json()
            content = result["choices"][0]["message"]["content"]
            return json.loads(content)
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            return {"error": str(e)}
    
    def process_audio_file(self, audio_path: str) -> Dict[str, Any]:
        """Full pipeline: transcribe + LLM process"""
        transcription = self.transcribe_audio(audio_path)
        if "error" in transcription and transcription["error"]:
            return {"error": transcription["error"]}
        
        llm_result = self.process_with_llm(transcription["text"])
        return {
            "transcript": transcription["text"],
            "order": llm_result
        }
    
    def text_to_speech(self, text: str, lang: str = "ur") -> Optional[bytes]:
        """Convert AI response text to speech"""
        try:
            response = requests.post(
                "https://api.voicerss.org/",
                data={
                    "key": os.getenv("VOICERSS_API_KEY", ""),
                    "src": text,
                    "hl": lang,
                    "v": "Bilal",
                    "c": "WAV",
                    "f": "8khz_8bit_mono"
                },
                timeout=15
            )
            return response.content if response.status_code == 200 else None
        except Exception as e:
            logger.error(f"TTS error: {e}")
            return None


if __name__ == "__main__":
    pipeline = VoicePipeline()
    pipeline.initialize_whisper()
    print("Azeem AI Voice Pipeline ready.")
    
    # Test with sample text
    test_transcript = "Salam, menu mein se Chicken Tikka aur Mighty Zinger chahta hoon, delivery FB Area mein, payment JazzCash"
    print(f"Testing LLM with: {test_transcript}")
    result = pipeline.process_with_llm(test_transcript)
    print(f"LLM Result: {json.dumps(result, indent=2)}")
