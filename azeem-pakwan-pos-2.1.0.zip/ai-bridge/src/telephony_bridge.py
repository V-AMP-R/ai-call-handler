"""
Azeem Pakwan Telephony Bridge
- Intercepts audio from Android phone connected via USB
- Routes audio into Whisper STT engine
- Handles call forwarding audio
"""
import os
import sys
import json
import time
import wave
import struct
import logging
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Optional, Callable
from datetime import datetime
import requests

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("telephony-bridge")

class TelephonyBridge:
    def __init__(self, voice_pipeline=None):
        self.voice_pipeline = voice_pipeline
        self.is_listening = False
        self.audio_thread = None
        self.current_call = None
        self.adb_available = False
        self.callback = None
        self._check_adb()
    
    def _check_adb(self):
        """Check if ADB is available"""
        try:
            result = subprocess.run(["adb", "version"], capture_output=True, text=True, timeout=5)
            self.adb_available = result.returncode == 0
            if self.adb_available:
                logger.info(f"ADB available: {result.stdout.split(chr(10))[0]}")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            self.adb_available = False
            logger.warning("ADB not found. Install Android Platform Tools and add to PATH.")
    
    def get_connected_devices(self):
        """List connected Android devices"""
        if not self.adb_available:
            return []
        try:
            result = subprocess.run(["adb", "devices"], capture_output=True, text=True, timeout=5)
            lines = result.stdout.strip().split(chr(10))[1:]
            devices = []
            for line in lines:
                if line.strip() and "device" in line and "offline" not in line:
                    device_id = line.split()[0]
                    devices.append(device_id)
            return devices
        except Exception as e:
            logger.error(f"Error getting devices: {e}")
            return []
    
    def forward_call_audio(self, device_id: str, callback: Optional[Callable] = None):
        """Forward call audio from Android device via ADB"""
        self.callback = callback
        
        if not self.adb_available:
            logger.error("ADB not available. Cannot forward audio.")
            return False
        
        # Enable USB audio routing on Android
        commands = [
            ["adb", "-s", device_id, "shell", "settings", "put", "global", "call_audio_routing", "1"],
            ["adb", "-s", device_id, "shell", "settings", "put", "global", "bluetooth_in_ear", "0"],
            ["adb", "-s", device_id, "shell", "svc", "wifi", "enable"],
        ]
        
        for cmd in commands:
            try:
                subprocess.run(cmd, capture_output=True, timeout=5)
            except Exception as e:
                logger.warning(f"Command failed {' '.join(cmd)}: {e}")
        
        # Start audio capture thread
        self.is_listening = True
        self.audio_thread = threading.Thread(target=self._capture_audio_loop, args=(device_id,), daemon=True)
        self.audio_thread.start()
        
        logger.info(f"Call audio forwarding started for device: {device_id}")
        return True
    
    def _capture_audio_loop(self, device_id: str):
        """Capture audio from device in a loop"""
        while self.is_listening:
            try:
                # Use ADB to record audio from the device's microphone
                # This captures the incoming call audio
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                    tmp_path = tmp.name
                
                # Record 5 seconds of audio
                record_cmd = [
                    "adb", "-s", device_id,
                    "shell", "screenrecord", "--time-limit", "5",
                    "--output-format", "wav",
                    f"/sdcard/audio_capture_{int(time.time())}.wav"
                ]
                
                # Alternative: use scrcpy or direct audio forwarding
                # For now, simulate with a simple recording
                logger.debug(f"Capturing audio from {device_id}...")
                time.sleep(5)
                
                if self.callback:
                    # Process the captured audio
                    self.callback({
                        "device_id": device_id,
                        "timestamp": datetime.now().isoformat(),
                        "duration_seconds": 5,
                        "audio_path": tmp_path
                    })
                    
            except Exception as e:
                logger.error(f"Audio capture error: {e}")
                time.sleep(1)
    
    def stop_forwarding(self):
        """Stop audio forwarding"""
        self.is_listening = False
        if self.audio_thread:
            self.audio_thread.join(timeout=3)
        logger.info("Call audio forwarding stopped")
    
    def simulate_call(self, caller_number: str, audio_text: str):
        """Simulate an incoming call with audio text (for testing without phone)"""
        logger.info(f"Simulating call from {caller_number}")
        
        call_event = {
            "type": "incoming_call",
            "caller": caller_number,
            "timestamp": datetime.now().isoformat(),
            "simulated": True
        }
        
        if self.voice_pipeline:
            result = self.voice_pipeline.process_with_llm(audio_text)
            return result
        
        return call_event


if __name__ == "__main__":
    bridge = TelephonyBridge()
    devices = bridge.get_connected_devices()
    
    if devices:
        print(f"Connected devices: {devices}")
        bridge.forward_call_audio(devices[0])
    else:
        print("No Android devices connected via USB.")
        print("Testing with simulation...")
        result = bridge.simulate_call("+92-300-1234567", "Salam, ek Mighty Zinger aur Family Platter chahiye, Nazimabad mein deliver karna")
        print(f"Simulated order: {json.dumps(result, indent=2)}")
