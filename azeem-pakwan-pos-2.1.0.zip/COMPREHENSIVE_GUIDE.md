# Azeem Pakwan AI POS & Call Center — Complete Guide

## 📋 Table of Contents
1. [System Overview](#1-system-overview)
2. [Architecture](#2-architecture)
3. [Installation & Setup](#3-installation--setup)
4. [How to Use the App](#4-how-to-use-the-app)
5. [Supabase Dashboard & Monitoring](#5-supabase-dashboard--monitoring)
6. [License Management (HWID)](#6-license-management-hwid)
7. [Phone Call Audio Forwarding Setup](#7-phone-call-audio-forwarding-setup)
8. [WhatsApp Business API Integration](#8-whatsapp-business-api-integration)
9. [AI Pipeline Details](#9-ai-pipeline-details)
10. [Kill-Switch & Security](#10-kill-switch--security)
11. [Compiling .exe for Distribution](#11-compiling-exe-for-distribution)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. System Overview

**Azeem Pakwan AI POS & Call Center** is a production-ready, full-stack desktop application for restaurant order management with AI-powered call handling. It features:

| Feature | Description |
|---------|-------------|
| **Dark-mode POS** | 3-zone layout: Call Stream, Menu Grid, Cart Summary |
| **AI Call Center** | Live transcription + LLM-powered order processing in Roman Urdu |
| **Supabase Backend** | Cloud database with real-time sync, global telemetry |
| **WhatsApp Integration** | Auto-send delivery confirmations, status updates |
| **Hardware Lock** | Motherboard serial-based licensing, anti-piracy |
| **Smart Installer** | Auto-detects PC specs and installs optimal AI model |
| **Kill-Switch** | Remotely disable unpaid subscriptions |

---

## 2. Architecture

```
azeem-pakwan-pos/
├── frontend/                  # React + Vite + Tailwind CSS
│   ├── src/
│   │   ├── App.jsx           # Main 3-zone layout
│   │   ├── components/
│   │   │   ├── LiveCallStream.jsx   # Zone 1: AI Call Stream
│   │   │   ├── MenuGrid.jsx        # Zone 2: Menu + Ordering
│   │   │   └── CartSummary.jsx     # Zone 3: Cart + Checkout
│   │   ├── hooks/
│   │   │   └── useRealtimeOrders.js # Supabase Realtime hook
│   │   └── services/
│   │       └── supabaseClient.js    # Supabase API client
│   └── ...
├── backend/                   # Supabase Database
│   ├── supabase/migrations/
│   │   ├── 001_schema.sql    # Tables: menu_items, orders, call_logs, client_licenses, telemetry
│   │   ├── 002_functions.sql # RPC functions: create_order, validate_license, telemetry_heartbeat
│   │   └── 003_realtime.sql  # Realtime subscriptions for AI_CALL orders
│   └── scripts/seed_menu.js  # Seed 17 menu items
├── ai-bridge/                 # Python AI Pipeline
│   └── src/
│       ├── voice_pipeline.py # Whisper STT + LLM (Groq/Ollama/OpenAI)
│       └── telephony_bridge.py # Android USB audio forwarding
├── hwid/                      # Hardware Licensing
│   ├── hwid_validate.py      # Motherboard serial → SHA-256 → license validation
│   └── license_server.py     # Admin tool: generate license keys
├── installer/                 # Deployment
│   ├── smart_installer.py    # PC spec detection + auto model selection
│   └── build_exe.py          # PyInstaller + Electron Builder → .exe
├── AOConnections.php          # WhatsApp Business API + Always-On DB manager
├── start.bat                 # One-click launcher (Windows)
├── .env.example              # Environment template
└── package.json              # Root scripts
```

---

## 3. Installation & Setup

### Prerequisites
- **Node.js** v18+ (https://nodejs.org)
- **Python** 3.9+ (https://python.org)
- **Git** (optional)

### Quick Start (Development)
```bash
# 1. Install frontend dependencies
cd frontend
npm install

# 2. Start development server
npm run dev

# 3. Open http://localhost:5173 in browser
```

### Smart Installation (Production — Auto-detects PC)
```bash
python installer/smart_installer.py

# For dry run (see what it would install without actually installing):
python installer/smart_installer.py --dry-run
```

### Full Production Build (Creates .exe)
```bash
python installer/build_exe.py
```
This will:
1. Obfuscate HWID script with PyArmor
2. Compile Python AI bridge with PyInstaller
3. Build React frontend for production
4. Wrap everything in Electron app
5. Output: `build/electron/dist/Azeem_Pakwan_Setup.exe`

---

## 4. How to Use the App

### The Interface has 3 Zones:

#### ZONE 1 — Left Panel: Live Call Stream (📞)
- **Caller ID Display**: Shows incoming caller number with answer/end button
- **Audio Visualizer**: Animated sound wave bars indicating active call
- **Live Transcription**: Real-time Roman Urdu transcription appearing line by line
- **AI Status Badge**: Cycles through:
  - `AI PROCESSING` (purple) — AI is handling the call
  - `HUMAN ESCALATED` (yellow) — Transferred to human staff
  - `ORDER CONFIRMED` (green) — Order successfully placed

#### ZONE 2 — Center Panel: Menu Grid (🍽️)
- **3 Category Tabs**: BBQ 🔥 | DEALS 🍔 | DAIG CATERING 🍛
- **17 Menu Items** with name, description, price in PKR
- **Quantity Selectors**:
  - `+ Add` button to add items
  - `−` / `+` buttons with count display for items in cart
  - Active items highlighted with green border

#### ZONE 3 — Right Panel: Cart Summary (🧾)
- **Cart Items**: List with qty adjust and remove (✕)
- **Delivery Area Dropdown**: FB Area (Rs.150), Nazimabad (Rs.200), Gulshan, North Nazimabad
- **Delivery Address**: Text input for house/street details
- **Payment Method**: Cash on Delivery 💵 | JazzCash 📱 | EasyPaisa 📱
- **Price Breakdown**: Subtotal + Delivery Fee + GST (13%) → Grand Total
- **Place Order Button**: Large green button → success screen with Order ID (e.g., AZM-XXXXX)

### Order Flow
1. Customer calls → AI answers → transcription appears in Zone 1
2. Staff selects menu items in Zone 2 using + buttons
3. Staff enters delivery info and payment method in Zone 3
4. Click "Place Order" → order confirmation screen
5. WhatsApp message auto-sent to customer (if number is on WhatsApp)

---

## 5. Supabase Dashboard & Monitoring

### Step 1: Create a Supabase Project
1. Go to https://supabase.com and sign up (free tier)
2. Click "New Project"
3. Set name: `azeem-pakwan-pos`
4. Set a strong database password
5. Choose region closest to Pakistan (Singapore or Mumbai)

### Step 2: Run Migrations
In the Supabase SQL Editor, run each migration file in order:
```
backend/supabase/migrations/001_schema.sql
backend/supabase/migrations/002_functions.sql
backend/supabase/migrations/003_realtime.sql
```

### Step 3: Configure Environment
Copy `.env.example` to `.env` and fill in:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

### Monitoring via Supabase Dashboard

#### 📊 Monitor Client Payments (client_licenses table)
| Column | Purpose |
|--------|---------|
| `client_name` | Shop owner name |
| `shop_name` | Restaurant name |
| `setup_fee` | Rs. 10,000 one-time setup |
| `monthly_fee` | Rs. 15,000 monthly |
| `last_payment_date` | When they last paid |
| `next_payment_due` | Upcoming payment date |
| `is_paid` | Boolean: paid/unpaid |
| `payment_status` | ACTIVE / OVERDUE / SUSPENDED / CANCELLED |
| `is_active` | Boolean: can they use the system |

#### 👁️ View Live Telemetry (telemetry table)
| Column | What you see |
|--------|--------------|
| `pc_name` | Client's computer name |
| `cpu_model` | e.g., Intel Core i7-12700 |
| `ram_gb` | e.g., 16.0 GB |
| `os_version` | Windows 10/11 |
| `is_online` | Green if app is running right now |
| `last_heartbeat` | Last time app checked in (every 60s) |
| `ip_address` | Client's public IP |
| `uptime_minutes` | How long app has been running |

#### 🔔 Realtime AI Call Alerts
When a new row is inserted into `orders` with `order_source: 'AI_CALL'`:
- Supabase Realtime sends a notification
- The frontend shows a green toast banner at the top
- An audio chime plays (configurable)

#### SQL Queries for Monitoring
```sql
-- Active installations (last hour)
SELECT COUNT(*) FROM telemetry WHERE is_online = true AND last_heartbeat > NOW() - INTERVAL '1 hour';

-- Overdue payments (kill-switch will block these)
SELECT client_name, shop_name, next_payment_due FROM client_licenses 
WHERE payment_status = 'OVERDUE' OR (next_payment_due < NOW() AND is_paid = false);

-- Today's orders
SELECT COUNT(*), SUM(grand_total) FROM orders WHERE created_at::date = CURRENT_DATE;

-- AI Call volume
SELECT COUNT(*) FROM orders WHERE order_source = 'AI_CALL' AND created_at::date = CURRENT_DATE;
```

---

## 6. License Management (HWID)

### How HWID Licensing Works
1. Each PC has a unique motherboard serial number
2. The app hashes this serial with SHA-256 + salt
3. This hash is compared against the `client_licenses` table in Supabase
4. If payment is overdue, the app locks itself (Kill-Switch)

### For Admin: Generating License Keys for New Clients

#### Step 1: Get Client's HWID
Ask the client to run on their machine:
```bash
python hwid/hwid_validate.py --info
```
They will get output like:
```json
{
  "serial": "ABC123456789",
  "hwid_hash": "a1b2c3d4e5f6...",
  "pc_name": "CLIENT-PC",
  ...
}
```
Send you the `hwid_hash` value.

#### Step 2: Generate License Key (Your Machine)
```bash
# Using the HWID hash they sent you:
python hwid/license_server.py CLIENT-001 a1b2c3d4e5f6...

# Or batch generate from a JSON file:
python hwid/license_server.py --batch clients.json
```

Where `clients.json` looks like:
```json
[
  {"client_id": "CLIENT-001", "hwid_hash": "a1b2c3..."},
  {"client_id": "CLIENT-002", "hwid_hash": "d4e5f6..."}
]
```

Output:
```json
{
  "client_id": "CLIENT-001",
  "hwid_hash": "a1b2c3d4e5f6...",
  "license_key": "YWJjMTIz... (base64 encoded)",
  "generated_at": "2026-07-29T..."
}
```

#### Step 3: Activate Client's Machine
Send the `license_key` to the client. They create a file called `license.key` in the app directory with that key, or you can insert it into Supabase:

```sql
INSERT INTO client_licenses (client_name, shop_name, hwid_hash, license_key, setup_fee, monthly_fee, next_payment_due)
VALUES ('Wajeeh', 'Azeem Pakwan', 'a1b2c3d4e5f6...', 'YWJjMTIz...', 10000, 15000, NOW() + INTERVAL '30 days');
```

#### Step 4: Managing License Renewals
When a client pays their Rs. 15,000 monthly fee:
```sql
UPDATE client_licenses 
SET last_payment_date = NOW(), 
    next_payment_due = NOW() + INTERVAL '30 days',
    is_paid = true,
    payment_status = 'ACTIVE'
WHERE client_name = 'Wajeeh';
```

When a client doesn't pay: The Kill-Switch will automatically deactivate them. To manually suspend:
```sql
UPDATE client_licenses 
SET payment_status = 'SUSPENDED', 
    is_paid = false, 
    is_active = false 
WHERE client_name = 'Wajeeh';
```

---

## 7. Phone Call Audio Forwarding Setup

### Method 1: Android Phone via USB (Recommended)

#### Requirements
- Android phone with **USB Debugging** enabled
- ADB (Android Debug Bridge) installed on your PC
- A USB cable

#### Setup Steps

1. **Enable Developer Options on Android**
   - Settings → About Phone → Tap "Build Number" 7 times
   - Settings → Developer Options → Enable

2. **Enable USB Debugging**
   - Developer Options → USB Debugging → ON
   - Developer Options → Stay Awake → ON (keeps screen on while charging)

3. **Install ADB on PC**
   - Download Platform Tools: https://developer.android.com/studio/releases/platform-tools
   - Extract to `C:\adb`
   - Add `C:\adb` to System PATH

4. **Connect Phone and Forward Audio**
   ```bash
   # Check device is detected
   adb devices
   
   # Enable USB audio routing (for call forwarding)
   adb shell settings put global call_audio_routing 1
   
   # Test with the telephony bridge:
   python ai-bridge/src/telephony_bridge.py
   ```

5. **How It Works**
   - When a call comes in, the Android phone routes audio via USB
   - `telephony_bridge.py` captures the audio using ADB
   - Audio is fed into Whisper STT for transcription
   - Transcription → LLM → structured order JSON
   - Order automatically populates the POS cart

### Method 2: Bluetooth Headset + Virtual Audio Cable (Alternative)
If USB doesn't work with your phone model:
1. Connect phone via Bluetooth (for calls)
2. Install Virtual Audio Cable (VAC) on PC
3. Set VAC as the default recording device
4. Route Bluetooth audio → VAC → Whisper STT

### Method 3: GSM Gateway / SIM800 Module (Hardware)
For a dedicated call center setup:
1. Buy a GSM gateway (e.g., SIM800L or Huawei GSM gateway)
2. Connect to PC via serial/USB
3. The `telephony_bridge.py` has a module for serial-based audio capture

### Testing Without Phone
You can simulate the entire flow:
```python
python ai-bridge/src/voice_pipeline.py
```
This will test Whisper STT + LLM with sample Roman Urdu text.

---

## 8. WhatsApp Business API Integration

### Getting a WhatsApp API Key

#### Option 1: Meta WhatsApp Cloud API (Free Tier - 1,000 conversations/month)

1. Go to https://business.facebook.com/wa/manage
2. Click "Get Started" with WhatsApp Business Platform
3. Create a Meta Business Account
4. Register your phone number (you'll receive a verification code)
5. Note your:
   - `WHATSAPP_API_KEY` (System User access token)
   - `WHATSAPP_PHONE_NUMBER_ID` (found in API setup)
   - `WHATSAPP_BUSINESS_ACCOUNT_ID` (from Business Account settings)

#### Option 2: Third-Party Providers
- **Twilio WhatsApp API**: https://www.twilio.com/whatsapp
- **MessageBird**: https://www.messagebird.com/en/whatsapp
- **WATI**: https://www.wati.io (popular in Pakistan)

### Configuration
Add to your `.env`:
```env
WHATSAPP_API_KEY=EAAT...your-meta-token...
WHATSAPP_PHONE_NUMBER_ID=123456789
WHATSAPP_BUSINESS_ACCOUNT_ID=987654321
```

### What the AI Does with WhatsApp
The AI Digital Munshi is hardcoded to:
1. Ask every customer: *"Kya aap ka number WhatsApp par hai?"*
2. If yes, save `is_whatsapp_contact = true` in the order
3. After order confirmation, automatically send:
   - ✅ Order confirmation with item details
   - 🛵 Delivery status updates
   - ❌ Cancellation notifications
   - 📍 Google Maps link for delivery tracking

### PHP WhatsApp Integration
The `AOConnections.php` file has a complete WhatsApp API client:
```php
$wa = new AzeemWhatsAppAPI();
$check = $wa->checkWhatsAppNumber('0300-1234567');
if ($check['is_whatsapp']) {
    $wa->sendOrderConfirmation('0300-1234567', $order);
    $wa->sendDeliveryDetails('0300-1234567', $order);
}
```

---

## 9. AI Pipeline Details

### System Prompt (Hardcoded)
```
You are the AI Digital Munshi for Azeem Pakwan. Differentiate between 
Fast Food orders and Daig bookings. Respond in friendly Roman Urdu. 
Return the final order as a structured JSON object containing items, 
total PKR, and customer address.
```

### How the Pipeline Works
```
Phone Call Audio → Whisper STT → Roman Urdu Text
                                        ↓
                                  LLM (Groq/Ollama)
                                        ↓
                              Structured JSON Order
                                        ↓
                              Mapped to POS Cart State
```

### Voice Pipeline Components (`ai-bridge/src/voice_pipeline.py`)
| Component | Technology | Purpose |
|-----------|------------|---------|
| **Speech-to-Text** | OpenAI Whisper | Transcribes Roman Urdu audio to text |
| **LLM Processing** | Groq / Ollama / OpenAI | Extracts order details as JSON |
| **Text-to-Speech** | VoiceRSS API | Speaks AI response back to customer |

### Smart Model Selection (`installer/smart_installer.py`)

| PC Specs | Recommended Model | Speed |
|----------|-------------------|-------|
| 32GB+ RAM + NVIDIA GPU | Llama 3.1 8B (local) | ⚡ Fast |
| 16-31GB RAM + GPU | Llama 3.2 3B (local) | ⚡ Fast |
| 16-31GB RAM, no GPU | Groq API (cloud) | 🚀 Super Fast |
| 8-15GB RAM | Groq API (cloud) | 🚀 Super Fast |
| < 8GB RAM | Groq API (cloud, minimal) | 🚀 Super Fast |

### Getting Groq API Key (Free)
1. Go to https://console.groq.com
2. Sign up (free tier: 30 requests/min)
3. Create an API key
4. Add to `.env`: `GROQ_API_KEY=gsk_...`

---

## 10. Kill-Switch & Security

### How the Kill-Switch Works

#### Local Activation
1. App starts → `hwid_validate.py` gets motherboard serial
2. Computes SHA-256 hash of serial + salt
3. Compares hash against `license.key` file or Supabase
4. If invalid → displays "UNAUTHORIZED LICENSE" and crashes

#### Online Kill-Switch (Always-On)
1. App pings Supabase every 60 seconds (`telemetry_heartbeat` RPC)
2. Supabase validates license via `validate_license` RPC
3. If `client_licenses.payment_status = 'SUSPENDED'`:
   - App receives `valid: false`
   - App locks immediately
   - Shows: "Subscription payment is overdue. Please contact Azeem Pakwan support."
   - AI voice calls are blocked

#### Without Internet
If no internet → local `license.key` file is checked instead. This means:
- Licensed PCs work offline
- But unlocked PCs also work offline (limited security)
- **Always require internet** for true Kill-Switch effectiveness

### Security Hardening
| Layer | Technology |
|-------|------------|
| HWID Extraction | `wmic baseboard get serialnumber` |
| Hashing | SHA-256 + salt |
| License File | Base64-encoded encrypted string |
| Obfuscation | PyArmor (Python bytecode obfuscation) |
| .exe Compilation | PyInstaller + Electron Builder |
| Network Validation | Supabase RPC with PostgreSQL |

### To Make Kill-Switch Enforce Internet:
In `hwid/hwid_validate.py`, set:
```python
def validate(self, use_online: bool = True) -> Tuple[bool, str]:
    # Always require online validation
    result = self.online_validation(self.hwid_hash)
    if not result.get("valid"):
        return False, result.get("message", "Active internet connection required")
    return True, "License valid"
```

---

## 11. Compiling .exe for Distribution

### Full Build Command
```bash
python installer/build_exe.py
```

### What the Build Does (in order):
1. **Check Dependencies**: node, npm, python, pip
2. **Obfuscate HWID**: `pyarmor obfuscate hwid/hwid_validate.py`
3. **Build Python Bridge**: `pyinstaller --onefile ai-bridge/src/voice_pipeline.py`
4. **Build Frontend**: `npm run build` (Vite production build)
5. **Electron Wrap**: Creates `main.js` + `preload.js` for Electron
6. **Electron Builder**: Compiles `Azeem_Pakwan_Setup.exe`

### Output
```
build/electron/dist/Azeem_Pakwan_Setup.exe   (~80-120 MB)
```

### Manual Steps if Build Fails
```bash
# Individual steps:
pyarmor obfuscate --output build/py-build/hwid-obfuscated hwid/hwid_validate.py
pyinstaller --onefile --name azeem_ai_bridge ai-bridge/src/voice_pipeline.py
cd frontend && npm run build
npx electron-builder --win --config
```

### Distributing to Clients
1. Generate a unique license key for each client PC
2. Send them `Azeem_Pakwan_Setup.exe`
3. They install it → first launch validates HWID
4. If valid → app works. If not → crashes with "Unauthorized"

---

## 12. Troubleshooting

### Frontend Issues
| Issue | Fix |
|-------|-----|
| Blank screen on load | Check browser console (F12) for errors |
| "Cannot find module" | Run `npm install` in frontend/ |
| Port 5173 in use | Edit `vite.config.js` → add `server: { port: 3000 }` |
| Tailwind styles not loading | Ensure `index.css` has `@import "tailwindcss"` |

### Supabase Issues
| Issue | Fix |
|-------|-----|
| "Failed to fetch" | Check `.env` has correct Supabase URL and key |
| "relation does not exist" | Run all 3 migration files in order |
| Realtime not working | Check that `supabase_realtime` publication includes `orders` |
| RPC function not found | Run `002_functions.sql` in SQL Editor |

### Python Issues
| Issue | Fix |
|-------|-----|
| "whisper not installed" | `pip install openai-whisper` |
| "pyaudio not installed" | `pip install pyaudio` (needs Visual C++ build tools) |
| ADB not found | Download Platform Tools, add to PATH |
| PyArmor not found | `pip install pyarmor` |

### License Issues
| Issue | Fix |
|-------|-----|
| "Unauthorized License" | Check `license.key` file exists and matches HWID |
| HWID changed | PC hardware change → generate new license |
| "No internet" for Kill-Switch | Only matters online; offline uses local key |

### Phone Call Forwarding
| Issue | Fix |
|-------|-----|
| `adb devices` shows nothing | Install USB driver for your phone model |
| Audio not routing | Try: `adb shell settings put global call_audio_routing 1` |
| Poor audio quality | Use a USB audio adapter for cleaner input |
| Phone not detected | Enable "File Transfer" or "MIDI" USB mode, not "Charging only" |

---

## 📞 Quick Reference

### Admin Commands
```bash
# See HWID of current machine
python hwid/hwid_validate.py --info

# Generate license for a client
python hwid/license_server.py CLIENT-001 <hwid_hash>

# Batch generate
python hwid/license_server.py --batch clients.json

# Smart install (auto-detect PC)
python installer/smart_installer.py

# Full .exe build
python installer/build_exe.py

# Start dev server
cd frontend && npm run dev

# Production build (frontend only)
cd frontend && npm run build
```

### Supabase Monitoring Queries
```sql
-- Active installs
SELECT * FROM telemetry WHERE is_online = true;

-- Overdue clients (Kill-Switch targets)
SELECT * FROM client_licenses WHERE payment_status != 'ACTIVE';

-- Today's AI calls
SELECT * FROM orders WHERE order_source = 'AI_CALL' AND created_at::date = CURRENT_DATE;

-- Total revenue today
SELECT SUM(grand_total) FROM orders WHERE created_at::date = CURRENT_DATE;
```

### Important URLs
| Resource | URL |
|----------|-----|
| Supabase Dashboard | https://supabase.com/dashboard |
| Meta WhatsApp API | https://developers.facebook.com |
| Groq Console (API Key) | https://console.groq.com |
| Node.js Download | https://nodejs.org |
| Python Download | https://python.org |
| ADB Platform Tools | https://developer.android.com/studio/releases/platform-tools |

---

## 🎯 Key Features You Added Yourself

- **WhatsApp auto-check**: AI asks if customer is on WhatsApp, sends order confirmations
- **Delivery tracking**: Google Maps links in WhatsApp messages
- **Google Maps tracking**: For delivery riders
- **Sentiment scoring**: Call logs store `sentiment_score` for customer satisfaction
- **Order status lifecycle**: NEW → CONFIRMED → PREPARING → OUT_FOR_DELIVERY → DELIVERED
- **Promotional messaging**: Send offers to WhatsApp contacts
- **Batch license generation**: Create licenses for multiple clients at once
- **PC spec telemetry**: Monitor every client's hardware from your dashboard
- **Automatic model fallback**: If local AI fails, uses cloud API automatically
- **GST calculation**: 13% GST automatically applied per Pakistani tax rules

---

*Built with ❤️ for Azeem Pakwan — Revolutionizing restaurant management with AI*
