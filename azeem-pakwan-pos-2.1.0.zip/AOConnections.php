<?php
/**
 * Azeem Pakwan AI POS - WhatsApp Business API Integration
 * 
 * This PHP file provides WhatsApp messaging capabilities:
 * - Send delivery confirmations
 * - Send order status updates
 * - Send cancellation notifications
 * - Check if customer number is on WhatsApp
 * 
 * Integrates with the WhatsApp Cloud API (Meta)
 */

class AzeemWhatsAppAPI {
    private string $apiKey;
    private string $phoneNumberId;
    private string $businessAccountId;
    private string $apiVersion = 'v18.0';
    private string $baseUrl = 'https://graph.facebook.com';
    
    public function __construct() {
        $this->apiKey = getenv('WHATSAPP_API_KEY') ?: '';
        $this->phoneNumberId = getenv('WHATSAPP_PHONE_NUMBER_ID') ?: '';
        $this->businessAccountId = getenv('WHATSAPP_BUSINESS_ACCOUNT_ID') ?: '';
    }
    
    /**
     * Check if a phone number is registered on WhatsApp
     */
    public function checkWhatsAppNumber(string $phoneNumber): array {
        $url = "{$this->baseUrl}/{$this->apiVersion}/{$this->phoneNumberId}/contacts";
        
        $data = [
            'blocking' => 'wait',
            'contacts' => [['phone' => $this->formatPhoneNumber($phoneNumber)]],
            'force_check' => true,
        ];
        
        $response = $this->post($url, $data);
        $contacts = $response['contacts'] ?? [];
        
        return [
            'is_whatsapp' => !empty($contacts) && ($contacts[0]['status'] === 'valid'),
            'input' => $phoneNumber,
            'formatted' => $this->formatPhoneNumber($phoneNumber),
            'wa_id' => $contacts[0]['wa_id'] ?? null,
        ];
    }
    
    /**
     * Send order confirmation message
     */
    public function sendOrderConfirmation(string $phoneNumber, array $order): array {
        $message = $this->buildOrderMessage($order, 'confirmed');
        return $this->sendTextMessage($phoneNumber, $message);
    }
    
    /**
     * Send order status update
     */
    public function sendOrderStatusUpdate(string $phoneNumber, array $order): array {
        $statusMessages = [
            'CONFIRMED' => "🟢 *Order Confirmed!*\n\nAap ka order confirm ho gaya hai. Hum jald se jald tayyar kar rahe hain.",
            'PREPARING' => "👨‍🍳 *Order Being Prepared*\n\nAap ka order ab tayyar ho raha hai. Lagbhag 20-30 minute mein ready ho jayega.",
            'OUT_FOR_DELIVERY' => "🛵 *Out for Delivery!*\n\nAap ka order delivery ke liye nikal chuka hai. Jald hi aap tak pahunchega.",
            'DELIVERED' => "✅ *Order Delivered!*\n\nAap ka order deliver ho gaya. Umeed hai aapko pasand aaya hoga. Shukriya Azeem Pakwan choose karne ka!",
            'CANCELLED' => "❌ *Order Cancelled*\n\nAap ka order cancel kar diya gaya hai. Koi masla ho toh 0300-1234567 par rabta karein.",
        ];
        
        $message = $statusMessages[$order['order_status']] ?? "Order status: {$order['order_status']}";
        $message .= "\n\nOrder ID: {$order['order_number']}";
        
        return $this->sendTextMessage($phoneNumber, $message);
    }
    
    /**
     * Send delivery details with map link
     */
    public function sendDeliveryDetails(string $phoneNumber, array $order): array {
        $message = "🚚 *Delivery Details*\n\n"
                 . "Order: {$order['order_number']}\n"
                 . "Address: {$order['delivery_address']}\n"
                 . "Area: {$order['delivery_area']}\n"
                 . "Total: Rs. {$order['grand_total']}\n"
                 . "Payment: {$this->paymentMethodLabel($order['payment_method'])}\n\n"
                 . "Track: https://maps.google.com/?q={$order['delivery_address']}";
        
        return $this->sendTextMessage($phoneNumber, $message);
    }
    
    /**
     * Send cancellation notification
     */
    public function sendCancellationNotification(string $phoneNumber, array $order, string $reason = ''): array {
        $message = "❌ *Order Cancelled*\n\n"
                 . "Aap ka order #{$order['order_number']} cancel kar diya gaya hai.\n";
        
        if ($reason) {
            $message .= "Wajah: {$reason}\n\n";
        }
        
        $message .= "Koi masla ho toh Azeem Pakwan se rabta karein.\n📞 0300-1234567";
        
        return $this->sendTextMessage($phoneNumber, $message);
    }
    
    /**
     * Send AI-generated order suggestion / promotional message
     */
    public function sendPromotionalMessage(string $phoneNumber, string $message): array {
        $prefix = "🍗 *Azeem Pakwan - Special Offer* 🍗\n\n";
        return $this->sendTextMessage($phoneNumber, $prefix . $message);
    }
    
    /**
     * Core: Send text message via WhatsApp Cloud API
     */
    private function sendTextMessage(string $phoneNumber, string $message): array {
        $url = "{$this->baseUrl}/{$this->apiVersion}/{$this->phoneNumberId}/messages";
        
        $data = [
            'messaging_product' => 'whatsapp',
            'recipient_type' => 'individual',
            'to' => $this->formatPhoneNumber($phoneNumber),
            'type' => 'text',
            'text' => [
                'preview_url' => true,
                'body' => $message,
            ],
        ];
        
        return $this->post($url, $data);
    }
    
    /**
     * Build order message based on status
     */
    private function buildOrderMessage(array $order, string $status): string {
        $itemsText = '';
        foreach ($order['items'] as $item) {
            $itemsText .= "• {$item['qty']}x {$item['name']} - Rs. " . ($item['price'] * $item['qty']) . "\n";
        }
        
        $messages = [
            'confirmed' => "✅ *Order Confirmed!* ✅\n\n"
                         . "Azeem Pakwan mein aapka order confirm ho gaya hai!\n\n"
                         . "📋 *Order #{$order['order_number']}*\n"
                         . "{$itemsText}\n"
                         . "📍 Delivery: {$order['delivery_area']}\n"
                         . "💰 Total: Rs. {$order['grand_total']}\n"
                         . "💳 Payment: {$this->paymentMethodLabel($order['payment_method'])}\n\n"
                         . "Jald hi aap ka order deliver kar diya jayega. Shukriya! 🎉",
        ];
        
        return $messages[$status] ?? "Order #{$order['order_number']} - Status: {$status}";
    }
    
    /**
     * Format phone number to international format
     */
    private function formatPhoneNumber(string $phone): string {
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone) === 10) {
            $phone = '92' . $phone;
        } elseif (strlen($phone) === 11 && $phone[0] === '0') {
            $phone = '92' . substr($phone, 1);
        } elseif (strlen($phone) === 13 && substr($phone, 0, 2) === '92') {
            // Already properly formatted
        }
        return $phone;
    }
    
    /**
     * Get payment method label in Urdu
     */
    private function paymentMethodLabel(string $method): string {
        $labels = [
            'CASH' => 'Cash on Delivery 💵',
            'JAZZCASH' => 'JazzCash 📱',
            'EASYPAISA' => 'EasyPaisa 📱',
        ];
        return $labels[$method] ?? $method;
    }
    
    /**
     * HTTP POST helper
     */
    private function post(string $url, array $data): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->apiKey,
                'Content-Type: application/json',
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $decoded = json_decode($response, true) ?: [];
        $decoded['http_code'] = $httpCode;
        
        return $decoded;
    }
}

/**
 * AO - Always Online Database Connection Manager
 * Manages persistent connection to Supabase backend
 */
class AOConnections {
    private string $supabaseUrl;
    private string $supabaseKey;
    private string $appVersion = '1.0.0';
    
    public function __construct() {
        $this->supabaseUrl = getenv('VITE_SUPABASE_URL') ?: '';
        $this->supabaseKey = getenv('SUPABASE_SERVICE_ROLE_KEY') ?: getenv('VITE_SUPABASE_ANON_KEY') ?: '';
    }
    
    /**
     * Validate license with Supabase kill-switch
     */
    public function validateLicense(string $hwidHash): array {
        $url = "{$this->supabaseUrl}/rest/v1/rpc/validate_license";
        
        $response = $this->post($url, [
            'hwid_hash_input' => $hwidHash,
        ]);
        
        return $response;
    }
    
    /**
     * Send telemetry heartbeat
     */
    public function sendHeartbeat(array $systemInfo): array {
        $url = "{$this->supabaseUrl}/rest/v1/rpc/telemetry_heartbeat";
        
        return $this->post($url, $systemInfo);
    }
    
    /**
     * Create a new order
     */
    public function createOrder(array $orderData): array {
        $url = "{$this->supabaseUrl}/rest/v1/rpc/create_order";
        
        return $this->post($url, $orderData);
    }
    
    /**
     * Fetch menu items
     */
    public function getMenuItems(): array {
        $url = "{$this->supabaseUrl}/rest/v1/menu_items?select=*&order=created_at.asc";
        
        return $this->get($url);
    }
    
    /**
     * Log a call
     */
    public function logCall(array $callData): array {
        $url = "{$this->supabaseUrl}/rest/v1/call_logs";
        
        return $this->post($url, $callData);
    }
    
    /**
     * Check if client is paid (kill-switch check)
     */
    public function isClientActive(string $hwidHash): bool {
        $validation = $this->validateLicense($hwidHash);
        return $validation['valid'] ?? false;
    }
    
    /**
     * Get client license info
     */
    public function getLicenseInfo(string $hwidHash): array {
        $url = "{$this->supabaseUrl}/rest/v1/client_licenses?hwid_hash=eq.{$hwidHash}&select=*";
        
        return $this->get($url);
    }
    
    /**
     * Supabase REST GET
     */
    private function get(string $url): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER => [
                'apikey: ' . $this->supabaseKey,
                'Authorization: Bearer ' . $this->supabaseKey,
                'Content-Type: application/json',
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return [
            'data' => json_decode($response, true) ?: [],
            'http_code' => $httpCode,
        ];
    }
    
    /**
     * Supabase REST POST
     */
    private function post(string $url, array $data): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'apikey: ' . $this->supabaseKey,
                'Authorization: Bearer ' . $this->supabaseKey,
                'Content-Type: ' . (strpos($url, '/rpc/') !== false ? 'application/json' : 'application/json'),
                'Prefer: return=representation',
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return json_decode($response, true) ?: ['http_code' => $httpCode];
    }
}

// ============================================================
// USAGE EXAMPLES:
// ============================================================
// 
// 1. WhatsApp Integration:
//    $wa = new AzeemWhatsAppAPI();
//    $check = $wa->checkWhatsAppNumber('0300-1234567');
//    if ($check['is_whatsapp']) {
//        $wa->sendOrderConfirmation('0300-1234567', $order);
//    }
//
// 2. License Validation (Kill-Switch):
//    $conn = new AOConnections();
//    $isActive = $conn->isClientActive($hwidHash);
//    if (!$isActive) {
//        die("License suspended. Please contact Azeem Pakwan.");
//    }
//
// 3. Order Creation:
//    $order = $conn->createOrder([
//        'p_items' => json_encode([['name' => 'Chicken Tikka', 'price' => 350, 'qty' => 2]]),
//        'p_customer_name' => 'Wajeeh',
//        'p_customer_phone' => '0300-1234567',
//        'p_delivery_address' => 'House 12, Sector 15, FB Area',
//        'p_delivery_area' => 'FB Area',
//        'p_payment_method' => 'JAZZCASH',
//        'p_order_source' => 'AI_CALL',
//    ]);
